import { defineStore } from 'pinia'
export const useAuditStore = defineStore('audit', {
  state: () => ({
    auditList: [],
    statusFilter: 'all'
  }),
  actions: {
    setAuditList(list) {
      this.auditList = list
    },
    setStatusFilter(status) {
      this.statusFilter = status
    }
  }
}) 