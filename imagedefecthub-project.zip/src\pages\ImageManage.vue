<template>
  <div class="page-container">
    <div class="page-header">
      <div class="header-left">
        <h2>图像管理</h2>
        <el-tag type="info" size="small">{{ imageList.length }} 张图片</el-tag>
      </div>
      <div class="header-actions">
        <el-button type="primary" @click="handleBatchDelete" :disabled="selectedImages.length === 0">
          <el-icon><Delete /></el-icon>
          批量删除 ({{ selectedImages.length }})
        </el-button>
        <el-button @click="refreshImageList" :loading="refreshing">
          <el-icon><Refresh /></el-icon>
          刷新
        </el-button>
      </div>
    </div>

    <!-- 图片上传区域 -->
    <el-card class="upload-card" :class="{ 'upload-dragover': isDragOver }">
      <template #header>
        <div class="upload-header">
          <span>图片上传</span>
          <el-tag type="success" size="small" v-if="uploadFileList.length > 0">
            已选择 {{ uploadFileList.length }} 张
          </el-tag>
        </div>
      </template>
      
      <el-upload
        ref="uploadRef"
        class="image-uploader"
        drag
        multiple
        :limit="50"
        :auto-upload="false"
        :on-change="handleFileChange"
        :on-remove="handleFileRemove"
        :on-exceed="handleExceed"
        :file-list="uploadFileList"
        accept=".jpg,.jpeg,.png,.bmp"
        @drop="handleDrop"
        @dragover="handleDragOver"
        @dragleave="handleDragLeave"
      >
        <el-icon class="el-icon--upload"><Plus /></el-icon>
        <div class="el-upload__text">
          <strong>拖拽图片到此处</strong>
          <br>
          <span>或 <em>点击上传</em></span>
        </div>
        <template #tip>
          <div class="el-upload__tip">
            支持 JPG/PNG/BMP 格式，最多50张/次，单张不超过10MB
          </div>
        </template>
      </el-upload>

      <div class="upload-actions" v-if="uploadFileList.length > 0">
        <el-button type="primary" @click="handleUpload" :loading="uploading">
          <el-icon><Upload /></el-icon>
          {{ uploading ? `上传中... (${uploadProgress}/${uploadFileList.length})` : '开始上传' }}
        </el-button>
        <el-button type="success" @click="handleBatchDetect" :disabled="uploading">
          <el-icon><Search /></el-icon>
          批量检测缺陷
        </el-button>
        <el-button @click="clearUploadList">
          <el-icon><Delete /></el-icon>
          清空列表
        </el-button>
      </div>
    </el-card>

    <!-- 图片列表和预览 -->
    <el-card class="image-list-card">
      <template #header>
        <div class="list-header">
          <div class="list-title">
            <span>图片列表</span>
            <el-tag v-if="filteredImageList.length !== imageList.length" type="warning" size="small">
              已筛选 {{ filteredImageList.length }}/{{ imageList.length }}
            </el-tag>
          </div>
          <div class="list-actions">
            <el-select v-model="sortBy" placeholder="排序方式" style="width: 120px; margin-right: 12px;">
              <el-option label="上传时间" value="uploadTime" />
              <el-option label="文件名" value="name" />
              <el-option label="文件大小" value="size" />
            </el-select>
            <el-select v-model="sortOrder" placeholder="排序" style="width: 80px; margin-right: 12px;">
              <el-option label="降序" value="desc" />
              <el-option label="升序" value="asc" />
            </el-select>
            <el-select v-model="viewMode" placeholder="显示模式" style="width: 120px; margin-right: 12px;">
              <el-option label="网格视图" value="grid" />
              <el-option label="列表视图" value="list" />
            </el-select>
            <el-input
              v-model="searchKeyword"
              placeholder="搜索图片名称"
              style="width: 200px;"
              clearable
            >
              <template #prefix>
                <el-icon><Search /></el-icon>
              </template>
            </el-input>
          </div>
        </div>
      </template>

      <!-- 加载状态 -->
      <div v-if="loading" class="loading-container">
        <el-skeleton :rows="6" animated />
      </div>

      <!-- 空状态 -->
      <div v-else-if="filteredImageList.length === 0" class="empty-state">
        <el-empty 
          :image-size="120"
          :description="searchKeyword ? '没有找到匹配的图片' : '暂无图片，请先上传'"
        >
          <template #image>
            <el-icon class="empty-icon"><Picture /></el-icon>
          </template>
          <el-button type="primary" @click="scrollToUpload">立即上传</el-button>
        </el-empty>
      </div>

      <!-- 网格视图 -->
      <div v-else-if="viewMode === 'grid'" class="image-grid">
        <div
          v-for="image in sortedImageList"
          :key="image.id"
          class="image-item"
          :class="{ selected: selectedImages.includes(image.id) }"
          @click="toggleImageSelection(image.id)"
        >
          <div class="image-wrapper">
            <img 
              :src="image.url" 
              :alt="image.name" 
              @load="handleImageLoad" 
              @error="handleImageError"
              loading="lazy"
            />
            <div class="image-overlay">
              <el-checkbox
                :model-value="selectedImages.includes(image.id)"
                @change="(val) => toggleImageSelection(image.id)"
                @click.stop
              />
              <div class="overlay-actions">
                <el-tooltip content="预览" placement="top">
                  <el-button size="small" type="primary" @click.stop="previewImage(image)">
                    <el-icon><View /></el-icon>
                  </el-button>
                </el-tooltip>
                <el-tooltip content="下载" placement="top">
                  <el-button size="small" type="success" @click.stop="downloadImage(image)">
                    <el-icon><Download /></el-icon>
                  </el-button>
                </el-tooltip>
                <el-tooltip content="删除" placement="top">
                  <el-button size="small" type="danger" @click.stop="deleteImage(image.id)">
                    <el-icon><Delete /></el-icon>
                  </el-button>
                </el-tooltip>
              </div>
            </div>
            <div class="image-badge" v-if="image.isNew">
              <el-tag type="success" size="small">新上传</el-tag>
            </div>
          </div>
          <div class="image-info">
            <div class="image-name" :title="image.name">{{ image.name }}</div>
            <div class="image-meta">
              <span>{{ formatFileSize(image.size) }}</span>
              <span>{{ formatDate(image.uploadTime) }}</span>
            </div>
          </div>
        </div>
      </div>

      <!-- 列表视图 -->
      <el-table
        v-else
        :data="sortedImageList"
        @selection-change="handleSelectionChange"
        style="width: 100%"
        v-loading="loading"
      >
        <el-table-column type="selection" width="55" />
        <el-table-column label="预览" width="100">
          <template #default="{ row }">
            <div class="table-image-wrapper">
              <img :src="row.url" :alt="row.name" class="table-image" />
              <el-tag v-if="row.isNew" type="success" size="small" class="new-badge">新</el-tag>
            </div>
          </template>
        </el-table-column>
        <el-table-column prop="name" label="文件名" min-width="200">
          <template #default="{ row }">
            <div class="file-name">
              <span>{{ row.name }}</span>
              <el-tag v-if="row.isNew" type="success" size="small" style="margin-left: 8px;">新上传</el-tag>
            </div>
          </template>
        </el-table-column>
        <el-table-column prop="size" label="大小" width="100" sortable>
          <template #default="{ row }">
            {{ formatFileSize(row.size) }}
          </template>
        </el-table-column>
        <el-table-column prop="uploadTime" label="上传时间" width="180" sortable>
          <template #default="{ row }">
            {{ formatDate(row.uploadTime) }}
          </template>
        </el-table-column>
        <el-table-column label="操作" width="280" fixed="right">
          <template #default="{ row }">
            <el-button size="small" @click="previewImage(row)">
              <el-icon><View /></el-icon>
              预览
            </el-button>
            <el-button size="small" type="success" @click="downloadImage(row)">
              <el-icon><Download /></el-icon>
              下载
            </el-button>
            <el-button size="small" type="warning" @click="detectDefect(row)">
              <el-icon><Search /></el-icon>
              检测缺陷
            </el-button>
            <el-button size="small" type="danger" @click="deleteImage(row.id)">
              <el-icon><Delete /></el-icon>
              删除
            </el-button>
          </template>
        </el-table-column>
      </el-table>

      <!-- 分页 -->
      <div class="pagination-wrapper" v-if="filteredImageList.length > 0">
        <el-pagination
          v-model:current-page="currentPage"
          v-model:page-size="pageSize"
          :page-sizes="[12, 24, 48, 96]"
          :total="filteredImageList.length"
          layout="total, sizes, prev, pager, next, jumper"
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
        />
      </div>
    </el-card>

    <!-- 图片预览对话框 -->
    <el-dialog
      v-model="previewVisible"
      title="图片预览"
      width="80%"
      :before-close="handlePreviewClose"
      destroy-on-close
    >
      <div class="preview-container">
        <img :src="previewImageUrl" :alt="previewImageName" class="preview-image" />
        <div class="preview-info">
          <p><strong>文件名：</strong>{{ previewImageName }}</p>
          <p><strong>大小：</strong>{{ previewImageSize }}</p>
          <p><strong>上传时间：</strong>{{ previewImageTime }}</p>
        </div>
      </div>
      <template #footer>
        <span class="dialog-footer">
          <el-button @click="previewVisible = false">关闭</el-button>
          <el-button type="primary" @click="downloadPreviewImage">下载</el-button>
        </span>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, reactive, computed, onMounted, nextTick } from 'vue'
import { useRouter } from 'vue-router'
import { ElMessage, ElMessageBox } from 'element-plus'
import { 
  Plus, Search, View, Delete, Download, Upload, Refresh, Picture 
} from '@element-plus/icons-vue'
import { useDetectStore } from '@/stores/detect'

// 响应式数据
const uploadRef = ref()
const uploading = ref(false)
const loading = ref(false)
const refreshing = ref(false)
const uploadFileList = ref([])
const imageList = ref([])
const selectedImages = ref([])
const viewMode = ref('grid')
const searchKeyword = ref('')
const sortBy = ref('uploadTime')
const sortOrder = ref('desc')
const previewVisible = ref(false)
const previewImageUrl = ref('')
const previewImageName = ref('')
const previewImageSize = ref('')
const previewImageTime = ref('')
const isDragOver = ref(false)
const uploadProgress = ref(0)
const currentPage = ref(1)
const pageSize = ref(12)
const router = useRouter()

// 图片数据
const mockImages = []

// 计算属性
const filteredImageList = computed(() => {
  if (!searchKeyword.value) return imageList.value
  
  return imageList.value.filter(image => 
    image.name.toLowerCase().includes(searchKeyword.value.toLowerCase())
  )
})

const sortedImageList = computed(() => {
  const list = [...filteredImageList.value]
  
  list.sort((a, b) => {
    let aValue, bValue
    
    switch (sortBy.value) {
      case 'name':
        aValue = a.name.toLowerCase()
        bValue = b.name.toLowerCase()
        break
      case 'size':
        aValue = a.size
        bValue = b.size
        break
      case 'uploadTime':
      default:
        aValue = new Date(a.uploadTime)
        bValue = new Date(b.uploadTime)
        break
    }
    
    if (sortOrder.value === 'asc') {
      return aValue > bValue ? 1 : -1
    } else {
      return aValue < bValue ? 1 : -1
    }
  })
  
  return list
})

// 文件上传处理
const handleFileChange = (file, fileList) => {
  uploadFileList.value = fileList
}

const handleFileRemove = (file, fileList) => {
  uploadFileList.value = fileList
}

const handleExceed = () => {
  ElMessage.warning('最多只能上传50张图片')
}

const handleDragOver = (e) => {
  e.preventDefault()
  isDragOver.value = true
}

const handleDragLeave = (e) => {
  e.preventDefault()
  isDragOver.value = false
}

const handleDrop = (e) => {
  e.preventDefault()
  isDragOver.value = false
}

const handleUpload = async () => {
  if (uploadFileList.value.length === 0) {
    ElMessage.warning('请先选择要上传的图片')
    return
  }

  uploading.value = true
  uploadProgress.value = 0
  
  try {
    // 模拟上传过程
    for (let i = 0; i < uploadFileList.value.length; i++) {
      const file = uploadFileList.value[i]
      
      // 模拟上传延迟
      await new Promise(resolve => setTimeout(resolve, 300))
      
      // 创建预览URL
      const url = URL.createObjectURL(file.raw)
      
      // 添加到图片列表
      const newImage = {
        id: Date.now() + i,
        name: file.name,
        url: url,
        size: file.size,
        uploadTime: new Date().toISOString(),
        isNew: true
      }
      
      imageList.value.unshift(newImage)
      uploadProgress.value = i + 1
    }
    
    ElMessage.success(`成功上传 ${uploadFileList.value.length} 张图片`)
    clearUploadList()
    
    // 3秒后移除新上传标记
    setTimeout(() => {
      imageList.value.forEach(img => {
        if (img.isNew) img.isNew = false
      })
    }, 3000)
  } catch (error) {
    ElMessage.error('上传失败，请重试')
  } finally {
    uploading.value = false
    uploadProgress.value = 0
  }
}

const clearUploadList = () => {
  uploadFileList.value = []
  uploadRef.value?.clearFiles()
}

// 图片选择
const toggleImageSelection = (imageId) => {
  const index = selectedImages.value.indexOf(imageId)
  if (index > -1) {
    selectedImages.value.splice(index, 1)
  } else {
    selectedImages.value.push(imageId)
  }
}

const handleSelectionChange = (selection) => {
  selectedImages.value = selection.map(item => item.id)
}

// 图片预览
const previewImage = (image) => {
  previewImageUrl.value = image.url
  previewImageName.value = image.name
  previewImageSize.value = formatFileSize(image.size)
  previewImageTime.value = formatDate(image.uploadTime)
  previewVisible.value = true
}

const handlePreviewClose = () => {
  previewVisible.value = false
  previewImageUrl.value = ''
  previewImageName.value = ''
  previewImageSize.value = ''
  previewImageTime.value = ''
}

const downloadPreviewImage = () => {
  downloadImage({
    url: previewImageUrl.value,
    name: previewImageName.value
  })
}

const downloadImage = (image) => {
  const link = document.createElement('a')
  link.href = image.url
  link.download = image.name
  document.body.appendChild(link)
  link.click()
  document.body.removeChild(link)
  ElMessage.success('下载成功')
}

// 缺陷检测相关
const detectDefect = (image) => {
  // 将选中的图片传递到缺陷检测页面
  const detectStore = useDetectStore()
  detectStore.setSelectedImages([image])
  router.push('/detect')
}

const handleBatchDetect = () => {
  if (uploadFileList.value.length === 0) {
    ElMessage.warning('请先选择要检测的图片')
    return
  }
  
  // 将上传列表中的图片传递到缺陷检测页面
  const detectStore = useDetectStore()
  const imagesToDetect = uploadFileList.value.map(file => ({
    id: Date.now() + Math.random(),
    name: file.name,
    url: URL.createObjectURL(file.raw),
    size: file.size,
    uploadTime: new Date().toISOString(),
    isNew: true
  }))
  detectStore.setSelectedImages(imagesToDetect)
  router.push('/detect')
}

// 图片删除
const deleteImage = async (imageId) => {
  try {
    await ElMessageBox.confirm('确定要删除这张图片吗？', '提示', {
      confirmButtonText: '确定',
      cancelButtonText: '取消',
      type: 'warning'
    })
    
    const index = imageList.value.findIndex(img => img.id === imageId)
    if (index > -1) {
      imageList.value.splice(index, 1)
      ElMessage.success('删除成功')
    }
  } catch {
    // 用户取消删除
  }
}

const handleBatchDelete = async () => {
  if (selectedImages.value.length === 0) {
    ElMessage.warning('请先选择要删除的图片')
    return
  }

  try {
    await ElMessageBox.confirm(
      `确定要删除选中的 ${selectedImages.value.length} 张图片吗？`,
      '批量删除',
      {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }
    )
    
    imageList.value = imageList.value.filter(img => !selectedImages.value.includes(img.id))
    selectedImages.value = []
    ElMessage.success('批量删除成功')
  } catch {
    // 用户取消删除
  }
}

// 图片加载处理
const handleImageLoad = (event) => {
  // 图片加载成功
}

const handleImageError = (event) => {
  // 图片加载失败，设置默认图片
  event.target.src = 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTAwIiBoZWlnaHQ9IjEwMCIgdmlld0JveD0iMCAwIDEwMCAxMDAiIGZpbGw9Im5vbmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+CjxyZWN0IHdpZHRoPSIxMDAiIGhlaWdodD0iMTAwIiBmaWxsPSIjRjVGNUY1Ii8+Cjx0ZXh0IHg9IjUwIiB5PSI1MCIgZm9udC1mYW1pbHk9IkFyaWFsIiBmb250LXNpemU9IjE0IiBmaWxsPSIjOTk5IiB0ZXh0LWFuY2hvcj0ibWlkZGxlIiBkeT0iLjNlbSI+5Zu+54mH5Y2g5L2N5paH5Lu2PC90ZXh0Pgo8L3N2Zz4K'
}

// 分页处理
const handleSizeChange = (val) => {
  pageSize.value = val
  currentPage.value = 1
}

const handleCurrentChange = (val) => {
  currentPage.value = val
}

// 工具函数
const formatFileSize = (bytes) => {
  if (bytes === 0) return '0 B'
  const k = 1024
  const sizes = ['B', 'KB', 'MB', 'GB']
  const i = Math.floor(Math.log(bytes) / Math.log(k))
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i]
}

const formatDate = (dateString) => {
  return new Date(dateString).toLocaleString('zh-CN')
}

const refreshImageList = async () => {
  refreshing.value = true
  loading.value = true
  
  try {
    // 模拟刷新延迟
    await new Promise(resolve => setTimeout(resolve, 1000))
    ElMessage.success('刷新成功')
  } catch (error) {
    ElMessage.error('刷新失败')
  } finally {
    refreshing.value = false
    loading.value = false
  }
}

const scrollToUpload = () => {
  nextTick(() => {
    const uploadCard = document.querySelector('.upload-card')
    if (uploadCard) {
      uploadCard.scrollIntoView({ behavior: 'smooth' })
    }
  })
}

// 页面加载时初始化数据
onMounted(() => {
  loading.value = true
  
  // 模拟加载延迟
  setTimeout(() => {
    imageList.value = [...mockImages]
    loading.value = false
  }, 1000)
})
</script>

<style lang="scss" scoped>
.page-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;

  .header-left {
    display: flex;
    align-items: center;
    gap: 12px;
  }

  .header-actions {
    display: flex;
    gap: 12px;
  }
}

.upload-card {
  margin-bottom: 20px;
  transition: all 0.3s;

  &.upload-dragover {
    border-color: var(--primary-color);
    box-shadow: 0 0 0 2px rgba(125, 200, 255, 0.2);
  }

  .upload-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
  }

  .image-uploader {
    width: 100%;
    
    // 让拖拽区域居中
    .el-upload-dragger {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      min-height: 220px;
      text-align: center;
      padding: 40px 20px;
      
      .el-icon--upload {
        font-size: 48px;
        color: #c0c4cc;
        margin-bottom: 16px;
      }
      
      .el-upload__text {
        font-size: 16px;
        color: #606266;
        margin-bottom: 8px;
        font-weight: 500;
        
        strong {
          color: #303133;
        }
        
        em {
          color: var(--primary-color);
          font-style: normal;
        }
      }
      
      .el-upload__tip {
        font-size: 12px;
        color: #909399;
      }
    }
  }

  .upload-actions {
    margin-top: 16px;
    text-align: center;
  }
}

.image-list-card {
  .list-header {
    display: flex;
    justify-content: space-between;
    align-items: center;

    .list-title {
      display: flex;
      align-items: center;
      gap: 8px;
    }

    .list-actions {
      display: flex;
      align-items: center;
    }
  }
}

.loading-container {
  padding: 40px 20px;
}

.empty-state {
  padding: 60px 20px;
  text-align: center;

  .empty-icon {
    font-size: 80px;
    color: #c0c4cc;
  }
}

.image-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
  gap: 16px;
  padding: 16px 0;

  .image-item {
    border: 1px solid #e4e7ed;
    border-radius: 8px;
    overflow: hidden;
    cursor: pointer;
    transition: all 0.3s;

    &:hover {
      border-color: var(--primary-color);
      box-shadow: 0 2px 12px rgba(0, 0, 0, 0.1);
      transform: translateY(-2px);
    }

    &.selected {
      border-color: var(--primary-color);
      background-color: #f0f9ff;
    }

    .image-wrapper {
      position: relative;
      height: 150px;
      overflow: hidden;

      img {
        width: 100%;
        height: 100%;
        object-fit: cover;
        transition: transform 0.3s;
      }

      .image-overlay {
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: rgba(0, 0, 0, 0.6);
        display: flex;
        justify-content: space-between;
        align-items: flex-start;
        padding: 8px;
        opacity: 0;
        transition: opacity 0.3s;

        .overlay-actions {
          display: flex;
          gap: 4px;
        }
      }

      .image-badge {
        position: absolute;
        top: 8px;
        right: 8px;
      }

      &:hover {
        .image-overlay {
          opacity: 1;
        }

        img {
          transform: scale(1.05);
        }
      }
    }

    .image-info {
      padding: 12px;

      .image-name {
        font-size: 14px;
        color: #333;
        margin-bottom: 4px;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }

      .image-meta {
        display: flex;
        justify-content: space-between;
        font-size: 12px;
        color: #999;
      }
    }
  }
}

.table-image-wrapper {
  position: relative;
  display: inline-block;

  .table-image {
    width: 60px;
    height: 40px;
    object-fit: cover;
    border-radius: 4px;
  }

  .new-badge {
    position: absolute;
    top: -4px;
    right: -4px;
  }
}

.file-name {
  display: flex;
  align-items: center;
}

.preview-container {
  text-align: center;

  .preview-image {
    max-width: 100%;
    max-height: 60vh;
    object-fit: contain;
    border-radius: 8px;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
  }

  .preview-info {
    margin-top: 16px;
    text-align: left;
    padding: 16px;
    background: #f8f9fa;
    border-radius: 8px;

    p {
      margin: 8px 0;
      color: #666;
    }
  }
}

.pagination-wrapper {
  margin-top: 20px;
  text-align: center;
}

// 响应式设计
@media (max-width: 768px) {
  .page-header {
    flex-direction: column;
    align-items: flex-start;
    gap: 12px;
  }

  .image-grid {
    grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
    gap: 12px;
  }

  .list-header {
    flex-direction: column;
    align-items: flex-start;
    gap: 12px;
  }

  .list-actions {
    flex-wrap: wrap;
    gap: 8px;
  }
}
</style> 