from fastapi import APIRouter, HTTPException, Depends, Query
from fastapi.responses import JSONResponse
from pydantic import BaseModel
from typing import List, Optional
from datetime import datetime
from sqlalchemy.orm import Session

from models.database import get_db, AuditRecord, Image, DetectionResult, User
from utils.auth import get_current_user
from config import settings

router = APIRouter()

class AuditRequest(BaseModel):
    audit_status: str  # pending, approved, rejected
    notes: Optional[str] = None

class BatchAuditRequest(BaseModel):
    audit_records: List[int]
    audit_status: str
    notes: Optional[str] = None

@router.get("/list")
async def get_audit_list(
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    status: Optional[str] = Query(None),
    defect_type: Optional[str] = Query(None),
    start_date: Optional[str] = Query(None),
    end_date: Optional[str] = Query(None),
    search: Optional[str] = Query(None),
    db: Session = Depends(get_db)
):
    """获取审核列表"""
    try:
        # 构建查询
        query = db.query(AuditRecord).join(Image).join(DetectionResult)
        
        # 状态过滤
        if status:
            query = query.filter(AuditRecord.audit_status == status)
        
        # 缺陷类型过滤
        if defect_type:
            query = query.filter(DetectionResult.defect_type == defect_type)
        
        # 日期范围过滤
        if start_date:
            query = query.filter(AuditRecord.audited_at >= start_date)
        if end_date:
            query = query.filter(AuditRecord.audited_at <= end_date)
        
        # 搜索过滤
        if search:
            query = query.filter(Image.original_name.contains(search))
        
        # 排序
        query = query.order_by(AuditRecord.audited_at.desc())
        
        # 分页
        total = query.count()
        audit_records = query.offset((page - 1) * page_size).limit(page_size).all()
        
        # 格式化数据
        audit_list = []
        for record in audit_records:
            audit_list.append({
                "id": record.id,
                "image_id": record.image_id,
                "image_name": record.image.original_name,
                "image_url": f"/uploads/{record.image.filename}",
                "defect_type": record.detection_result.defect_type,
                "confidence": record.detection_result.confidence,
                "bbox": [
                    record.detection_result.bbox_x,
                    record.detection_result.bbox_y,
                    record.detection_result.bbox_width,
                    record.detection_result.bbox_height
                ],
                "audit_status": record.audit_status,
                "notes": record.notes,
                "audited_at": record.audited_at.isoformat(),
                "auditor": record.user.username if record.user else None
            })
        
        return JSONResponse(content={
            "code": 200,
            "data": {
                "audit_records": audit_list,
                "pagination": {
                    "page": page,
                    "page_size": page_size,
                    "total": total,
                    "total_pages": (total + page_size - 1) // page_size
                }
            }
        })
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"获取审核列表失败: {str(e)}")

@router.post("/{audit_id}")
async def update_audit_status(
    audit_id: int,
    audit_data: AuditRequest,
    current_user: str = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """更新审核状态"""
    try:
        audit_record = db.query(AuditRecord).filter(AuditRecord.id == audit_id).first()
        
        if not audit_record:
            raise HTTPException(status_code=404, detail="审核记录不存在")
        
        # 更新审核状态
        audit_record.audit_status = audit_data.audit_status
        audit_record.notes = audit_data.notes
        audit_record.audited_at = datetime.utcnow()
        
        # 获取当前用户ID
        user = db.query(User).filter(User.username == current_user).first()
        if user:
            audit_record.user_id = user.id
        
        db.commit()
        
        return JSONResponse(content={
            "code": 200,
            "message": "审核状态更新成功",
            "data": {
                "id": audit_record.id,
                "audit_status": audit_record.audit_status,
                "notes": audit_record.notes,
                "audited_at": audit_record.audited_at.isoformat()
            }
        })
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"更新审核状态失败: {str(e)}")

@router.post("/batch")
async def batch_audit(
    batch_data: BatchAuditRequest,
    current_user: str = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """批量审核"""
    try:
        # 获取当前用户ID
        user = db.query(User).filter(User.username == current_user).first()
        if not user:
            raise HTTPException(status_code=404, detail="用户不存在")
        
        updated_count = 0
        
        for audit_id in batch_data.audit_records:
            audit_record = db.query(AuditRecord).filter(AuditRecord.id == audit_id).first()
            
            if audit_record:
                audit_record.audit_status = batch_data.audit_status
                audit_record.notes = batch_data.notes
                audit_record.audited_at = datetime.utcnow()
                audit_record.user_id = user.id
                updated_count += 1
        
        db.commit()
        
        return JSONResponse(content={
            "code": 200,
            "message": f"批量审核完成，共更新 {updated_count} 条记录",
            "data": {
                "updated_count": updated_count,
                "audit_status": batch_data.audit_status
            }
        })
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"批量审核失败: {str(e)}")

@router.get("/statistics")
async def get_audit_statistics(
    db: Session = Depends(get_db)
):
    """获取审核统计信息"""
    try:
        # 总审核记录数
        total_records = db.query(AuditRecord).count()
        
        # 按状态统计
        status_stats = db.query(
            AuditRecord.audit_status,
            db.func.count(AuditRecord.id).label('count')
        ).group_by(AuditRecord.audit_status).all()
        
        # 按缺陷类型统计
        defect_stats = db.query(
            DetectionResult.defect_type,
            db.func.count(DetectionResult.id).label('count')
        ).group_by(DetectionResult.defect_type).all()
        
        return JSONResponse(content={
            "code": 200,
            "data": {
                "total_records": total_records,
                "status_statistics": [
                    {"status": stat.audit_status, "count": stat.count}
                    for stat in status_stats
                ],
                "defect_statistics": [
                    {"defect_type": stat.defect_type, "count": stat.count}
                    for stat in defect_stats
                ]
            }
        })
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"获取审核统计失败: {str(e)}")

@router.get("/pending-count")
async def get_pending_count(
    db: Session = Depends(get_db)
):
    """获取待审核数量"""
    try:
        pending_count = db.query(AuditRecord).filter(
            AuditRecord.audit_status == "pending"
        ).count()
        
        return JSONResponse(content={
            "code": 200,
            "data": {
                "pending_count": pending_count
            }
        })
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"获取待审核数量失败: {str(e)}") 