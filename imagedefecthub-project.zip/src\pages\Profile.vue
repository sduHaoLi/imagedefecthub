<template>
  <div class="page-container">
    <div class="profile-header">
      <h2>个人信息</h2>
      <p class="subtitle">管理您的账户信息和偏好设置</p>
    </div>

    <el-row :gutter="24">
      <!-- 左侧：基本信息 -->
      <el-col :span="16">
        <el-card class="profile-card">
          <template #header>
            <div class="card-header">
              <span>基本信息</span>
              <el-button type="primary" @click="handleSave" :loading="saving">
                保存修改
              </el-button>
            </div>
          </template>

          <el-form :model="userForm" :rules="rules" ref="formRef" label-width="100px">
            <el-row :gutter="20">
              <el-col :span="12">
                <el-form-item label="用户名" prop="username">
                  <el-input v-model="userForm.username" placeholder="请输入用户名" />
                </el-form-item>
              </el-col>
              <el-col :span="12">
                <el-form-item label="真实姓名" prop="realName">
                  <el-input v-model="userForm.realName" placeholder="请输入真实姓名" />
                </el-form-item>
              </el-col>
            </el-row>

            <el-row :gutter="20">
              <el-col :span="12">
                <el-form-item label="邮箱" prop="email">
                  <el-input v-model="userForm.email" placeholder="请输入邮箱地址" />
                </el-form-item>
              </el-col>
              <el-col :span="12">
                <el-form-item label="手机号" prop="phone">
                  <el-input v-model="userForm.phone" placeholder="请输入手机号" />
                </el-form-item>
              </el-col>
            </el-row>

            <el-form-item label="所属部门" prop="department">
              <el-select v-model="userForm.department" placeholder="请选择部门" style="width: 100%">
                <el-option label="质检部" value="质检部" />
                <el-option label="生产部" value="生产部" />
                <el-option label="技术部" value="技术部" />
                <el-option label="管理部" value="管理部" />
              </el-select>
            </el-form-item>

            <el-form-item label="职位" prop="position">
              <el-input v-model="userForm.position" placeholder="请输入职位" />
            </el-form-item>

            <el-form-item label="个人简介" prop="bio">
              <el-input
                v-model="userForm.bio"
                type="textarea"
                :rows="4"
                placeholder="请输入个人简介"
              />
            </el-form-item>
          </el-form>
        </el-card>

        <!-- 密码修改 -->
        <el-card class="profile-card" style="margin-top: 20px;">
          <template #header>
            <span>修改密码</span>
          </template>

          <el-form :model="passwordForm" :rules="passwordRules" ref="passwordFormRef" label-width="100px">
            <el-form-item label="当前密码" prop="oldPassword">
              <el-input
                v-model="passwordForm.oldPassword"
                type="password"
                placeholder="请输入当前密码"
                show-password
              />
            </el-form-item>
            <el-form-item label="新密码" prop="newPassword">
              <el-input
                v-model="passwordForm.newPassword"
                type="password"
                placeholder="请输入新密码"
                show-password
              />
            </el-form-item>
            <el-form-item label="确认密码" prop="confirmPassword">
              <el-input
                v-model="passwordForm.confirmPassword"
                type="password"
                placeholder="请再次输入新密码"
                show-password
              />
            </el-form-item>
            <el-form-item>
              <el-button type="primary" @click="handleChangePassword" :loading="changingPassword">
                修改密码
              </el-button>
            </el-form-item>
          </el-form>
        </el-card>
      </el-col>

      <!-- 右侧：头像和统计 -->
      <el-col :span="8">
        <!-- 头像上传 -->
        <el-card class="profile-card">
          <template #header>
            <span>头像设置</span>
          </template>
          
          <div class="avatar-section">
            <el-avatar :size="120" :src="userForm.avatar" class="avatar-preview">
              <el-icon><User /></el-icon>
            </el-avatar>
            
            <div class="avatar-actions">
              <el-upload
                class="avatar-uploader"
                action="#"
                :show-file-list="false"
                :before-upload="beforeAvatarUpload"
                accept="image/*"
              >
                <el-button type="primary" size="small">更换头像</el-button>
              </el-upload>
              <p class="upload-tip">支持 JPG、PNG 格式，文件小于 2MB</p>
            </div>
          </div>
        </el-card>

        <!-- 账户统计 -->
        <el-card class="profile-card" style="margin-top: 20px;">
          <template #header>
            <span>账户统计</span>
          </template>
          
          <div class="stats-section">
            <div class="stat-item">
              <div class="stat-number">{{ stats.totalImages }}</div>
              <div class="stat-label">检测图片</div>
            </div>
            <div class="stat-item">
              <div class="stat-number">{{ stats.totalDefects }}</div>
              <div class="stat-label">发现缺陷</div>
            </div>
            <div class="stat-item">
              <div class="stat-number">{{ stats.auditCount }}</div>
              <div class="stat-label">审核次数</div>
            </div>
            <div class="stat-item">
              <div class="stat-number">{{ stats.joinDays }}</div>
              <div class="stat-label">加入天数</div>
            </div>
          </div>
        </el-card>

        <!-- 最近活动 -->
        <el-card class="profile-card" style="margin-top: 20px;">
          <template #header>
            <span>最近活动</span>
          </template>
          
          <div class="activity-list">
            <div v-if="recentActivities.length === 0" class="empty-activities">
              <el-empty description="暂无活动记录" :image-size="60">
                <template #image>
                  <el-icon style="font-size: 30px; color: #c0c4cc;"><Document /></el-icon>
                </template>
              </el-empty>
            </div>
            <div v-for="activity in recentActivities" :key="activity.id" class="activity-item">
              <div class="activity-icon">
                <el-icon><component :is="activity.icon" /></el-icon>
              </div>
              <div class="activity-content">
                <div class="activity-title">{{ activity.title }}</div>
                <div class="activity-time">{{ activity.time }}</div>
              </div>
            </div>
          </div>
        </el-card>
      </el-col>
    </el-row>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { Picture, Check, Document, User } from '@element-plus/icons-vue'
import { getUserInfo, updateUserInfo, changePassword, uploadAvatar } from '@/api/user'

// 表单引用
const formRef = ref()
const passwordFormRef = ref()

// 加载状态
const saving = ref(false)
const changingPassword = ref(false)

// 用户信息表单
const userForm = reactive({
  username: '',
  realName: '',
  email: '',
  phone: '',
  department: '',
  position: '',
  bio: '',
  avatar: ''
})

// 密码表单
const passwordForm = reactive({
  oldPassword: '',
  newPassword: '',
  confirmPassword: ''
})

// 表单验证规则
const rules = {
  username: [
    { required: true, message: '请输入用户名', trigger: 'blur' },
    { min: 3, max: 20, message: '长度在 3 到 20 个字符', trigger: 'blur' }
  ],
  realName: [
    { required: true, message: '请输入真实姓名', trigger: 'blur' }
  ],
  email: [
    { required: true, message: '请输入邮箱地址', trigger: 'blur' },
    { type: 'email', message: '请输入正确的邮箱地址', trigger: 'blur' }
  ],
  phone: [
    { required: true, message: '请输入手机号', trigger: 'blur' },
    { pattern: /^1[3-9]\d{9}$/, message: '请输入正确的手机号', trigger: 'blur' }
  ],
  department: [
    { required: true, message: '请选择部门', trigger: 'change' }
  ]
}

// 密码验证规则
const passwordRules = {
  oldPassword: [
    { required: true, message: '请输入当前密码', trigger: 'blur' }
  ],
  newPassword: [
    { required: true, message: '请输入新密码', trigger: 'blur' },
    { min: 6, message: '密码长度不能少于6位', trigger: 'blur' }
  ],
  confirmPassword: [
    { required: true, message: '请再次输入新密码', trigger: 'blur' },
    {
      validator: (rule, value, callback) => {
        if (value !== passwordForm.newPassword) {
          callback(new Error('两次输入密码不一致'))
        } else {
          callback()
        }
      },
      trigger: 'blur'
    }
  ]
}

// 统计数据
const stats = reactive({
  totalImages: 0,
  totalDefects: 0,
  auditCount: 0,
  joinDays: 0
})

// 最近活动
const recentActivities = ref([])

// 保存个人信息
const handleSave = async () => {
  try {
    await formRef.value.validate()
    saving.value = true
    
    // 调用API更新用户信息
    await updateUserInfo({
      username: userForm.username,
      realName: userForm.realName,
      email: userForm.email,
      phone: userForm.phone,
      department: userForm.department,
      position: userForm.position,
      bio: userForm.bio
    })
    
    ElMessage.success('个人信息保存成功')
  } catch (error) {
    console.error('保存个人信息失败:', error)
    ElMessage.error('保存失败，请重试')
  } finally {
    saving.value = false
  }
}

// 修改密码
const handleChangePassword = async () => {
  try {
    await passwordFormRef.value.validate()
    changingPassword.value = true
    
    // 调用API修改密码
    await changePassword({
      oldPassword: passwordForm.oldPassword,
      newPassword: passwordForm.newPassword
    })
    
    ElMessage.success('密码修改成功')
    
    // 清空密码表单
    passwordForm.oldPassword = ''
    passwordForm.newPassword = ''
    passwordForm.confirmPassword = ''
    passwordFormRef.value.resetFields()
  } catch (error) {
    console.error('密码修改失败:', error)
    ElMessage.error('密码修改失败，请检查当前密码是否正确')
  } finally {
    changingPassword.value = false
  }
}

// 头像上传前处理
const beforeAvatarUpload = async (file) => {
  const isJPG = file.type === 'image/jpeg'
  const isPNG = file.type === 'image/png'
  const isLt2M = file.size / 1024 / 1024 < 2

  if (!isJPG && !isPNG) {
    ElMessage.error('头像只能是 JPG 或 PNG 格式!')
    return false
  }
  if (!isLt2M) {
    ElMessage.error('头像大小不能超过 2MB!')
    return false
  }
  
  try {
    // 调用API上传头像
    const result = await uploadAvatar(file)
    userForm.avatar = result.avatarUrl
    ElMessage.success('头像上传成功')
  } catch (error) {
    console.error('头像上传失败:', error)
    ElMessage.error('头像上传失败，请重试')
  }
  
  return false // 阻止默认上传
}

// 页面加载时获取用户信息
onMounted(async () => {
  try {
    // 调用API获取用户信息
    const response = await getUserInfo()
    if (response && response.data) {
      Object.assign(userForm, response.data)
    } else {
      // 使用默认数据
      Object.assign(userForm, {
        username: 'admin',
        email: 'admin@example.com',
        phone: '13800138000',
        role: '管理员'
      })
    }
  } catch (error) {
    console.error('获取用户信息失败:', error)
    // 使用默认数据，不显示错误消息
    Object.assign(userForm, {
      username: 'admin',
      email: 'admin@example.com',
      phone: '13800138000',
      role: '管理员'
    })
  }
})
</script>

<style lang="scss" scoped>
.profile-header {
  margin-bottom: 24px;
  
  .subtitle {
    color: #666;
    margin-top: 8px;
  }
}

.profile-card {
  .card-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
  }
}

.avatar-section {
  text-align: center;
  
  .avatar-preview {
    margin-bottom: 16px;
  }
  
  .avatar-actions {
    .upload-tip {
      color: #999;
      font-size: 12px;
      margin-top: 8px;
    }
  }
}

.stats-section {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 16px;
  
  .stat-item {
    text-align: center;
    padding: 16px;
    background: #f8f9fa;
    border-radius: 8px;
    
    .stat-number {
      font-size: 24px;
      font-weight: bold;
      color: var(--primary-color);
      margin-bottom: 4px;
    }
    
    .stat-label {
      font-size: 12px;
      color: #666;
    }
  }
}

.activity-list {
  .empty-activities {
    padding: 20px 0;
    text-align: center;
  }
  
  .activity-item {
    display: flex;
    align-items: center;
    padding: 12px 0;
    border-bottom: 1px solid #f0f0f0;
    
    &:last-child {
      border-bottom: none;
    }
    
    .activity-icon {
      width: 32px;
      height: 32px;
      border-radius: 50%;
      background: var(--primary-color);
      display: flex;
      align-items: center;
      justify-content: center;
      margin-right: 12px;
      
      .el-icon {
        color: white;
        font-size: 16px;
      }
    }
    
    .activity-content {
      flex: 1;
      
      .activity-title {
        font-size: 14px;
        color: #333;
        margin-bottom: 4px;
      }
      
      .activity-time {
        font-size: 12px;
        color: #999;
      }
    }
  }
}

// 响应式设计
@media (max-width: 768px) {
  .el-col {
    width: 100% !important;
    margin-bottom: 20px;
  }
  
  .stats-section {
    grid-template-columns: 1fr;
  }
}
</style> 