import request from './request'

// 上传图片
export function uploadImage(data) {
  return request({
    url: '/images/upload',
    method: 'post',
    data,
    headers: {
      'Content-Type': 'multipart/form-data'
    }
  })
}

// 获取图片列表
export function getImageList(params) {
  return request({
    url: '/images/list',
    method: 'get',
    params
  })
}

// 删除图片
export function deleteImage(id) {
  return request({
    url: `/images/${id}`,
    method: 'delete'
  })
}

// 获取图片详情
export function getImageDetail(id) {
  return request({
    url: `/images/${id}`,
    method: 'get'
  })
}

// 识别图片缺陷
export function detectDefects(id, params) {
  return request({
    url: `/images/${id}/detect`,
    method: 'post',
    data: params
  })
}

// 更新图片审核状态
export function updateAuditStatus(id, status, comment) {
  return request({
    url: `/images/${id}/audit`,
    method: 'put',
    data: {
      status,
      comment
    }
  })
}

// 导出报告
export function exportReport(params) {
  return request({
    url: '/report/export',
    method: 'post',
    data: params,
    responseType: 'blob'
  })
} 