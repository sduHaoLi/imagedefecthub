<template>
  <div class="page-container">
    <!-- 页面标题 -->
    <div class="page-header">
      <h2>缺陷自动识别</h2>
      <p class="subtitle">使用AI模型自动检测图像中的缺陷，支持批量处理和实时预览</p>
    </div>

    <el-row :gutter="20">
      <!-- 左侧：参数配置和上传 -->
      <el-col :span="8">
        <!-- 检测参数配置 -->
        <el-card class="config-card" shadow="hover">
          <template #header>
            <span>检测参数配置</span>
          </template>
          
          <el-form :model="detectConfig" label-width="100px">
            <el-form-item label="检测模型">
              <el-select v-model="detectConfig.model" placeholder="选择检测模型" style="width: 100%">
                <el-option label="YOLOv8 (推荐)" value="yolov8" />
                <el-option label="Faster R-CNN" value="faster_rcnn" />
                <el-option label="SSD" value="ssd" />
              </el-select>
            </el-form-item>
            
            <el-form-item label="置信度阈值">
              <el-slider
                v-model="detectConfig.confidence"
                :min="0.1"
                :max="1"
                :step="0.05"
                show-input
                input-size="small"
              />
            </el-form-item>
            
            <el-form-item label="NMS阈值">
              <el-slider
                v-model="detectConfig.nms"
                :min="0.1"
                :max="1"
                :step="0.05"
                show-input
                input-size="small"
              />
            </el-form-item>
            
            <el-form-item label="检测类型">
              <el-checkbox-group v-model="detectConfig.defectTypes">
                <el-checkbox label="crack">裂纹</el-checkbox>
                <el-checkbox label="scratch">划痕</el-checkbox>
                <el-checkbox label="stain">污渍</el-checkbox>
                <el-checkbox label="dent">凹陷</el-checkbox>
                <el-checkbox label="color">色差</el-checkbox>
              </el-checkbox-group>
            </el-form-item>
            
            <el-form-item label="处理模式">
              <el-radio-group v-model="detectConfig.mode">
                <el-radio label="single">单张检测</el-radio>
                <el-radio label="batch">批量检测</el-radio>
              </el-radio-group>
            </el-form-item>
          </el-form>
        </el-card>

        <!-- 图片上传 -->
        <el-card class="upload-card" shadow="hover" style="margin-top: 20px;">
          <template #header>
            <span>图片上传</span>
            <el-tag v-if="selectedImages.length > 0" type="success" size="small" style="margin-left: 8px;">
              已选择 {{ selectedImages.length }} 张
            </el-tag>
          </template>
          
          <!-- 从图像管理传递的图片 -->
          <div v-if="selectedImages.length > 0" class="selected-images">
            <div class="selected-header">
              <span>从图像管理选择的图片：</span>
              <el-button size="small" @click="clearSelectedImages">清空</el-button>
            </div>
            <div class="image-grid">
              <div 
                v-for="image in selectedImages" 
                :key="image.id" 
                class="image-item"
                :class="{ 'selected': image.selected }"
                @click="toggleImageSelection(image)"
              >
                <img :src="image.url" :alt="image.name" />
                <div class="image-info">
                  <span class="image-name">{{ image.name }}</span>
                  <span class="image-size">{{ formatFileSize(image.size) }}</span>
                </div>
              </div>
            </div>
          </div>
          
          <el-divider v-if="selectedImages.length > 0">或</el-divider>
          
          <el-upload
            ref="uploadRef"
            class="image-uploader"
            action="#"
            :auto-upload="false"
            :show-file-list="true"
            :on-change="handleFileChange"
            :on-remove="handleFileRemove"
            :before-upload="beforeUpload"
            accept="image/*"
            multiple
            drag
          >
            <el-icon class="el-icon--upload"><Upload /></el-icon>
            <div class="el-upload__text">
              将图片拖到此处，或<em>点击上传</em>
            </div>
            <template #tip>
              <div class="el-upload__tip">
                支持 jpg/png 格式，单个文件不超过 10MB
              </div>
            </template>
          </el-upload>
          
          <div class="upload-actions" style="margin-top: 16px;">
            <el-button type="primary" @click="startDetection" :loading="detecting" :disabled="!hasImages">
              开始检测
            </el-button>
            <el-button @click="clearImages">清空图片</el-button>
          </div>
        </el-card>
      </el-col>

      <!-- 右侧：检测结果 -->
      <el-col :span="16">
        <el-card class="result-card" shadow="hover">
          <template #header>
            <div class="result-header">
              <span>检测结果</span>
              <div class="result-actions">
                <el-button size="small" @click="exportResults" :disabled="!hasResults">
                  <el-icon><Download /></el-icon>
                  导出结果
                </el-button>
                <el-button size="small" @click="clearResults" :disabled="!hasResults">
                  <el-icon><Delete /></el-icon>
                  清空结果
                </el-button>
              </div>
            </div>
          </template>
          
          <!-- 检测进度 -->
          <div v-if="detecting" class="detection-progress">
            <el-progress 
              :percentage="detectionProgress" 
              :format="progressFormat"
              status="success"
            />
            <p class="progress-text">正在检测第 {{ currentImageIndex + 1 }} 张图片...</p>
          </div>
          
          <!-- 结果列表 -->
          <div v-else-if="hasResults" class="result-list">
            <div v-for="result in detectionResults" :key="result.id" class="result-item">
              <div class="result-image">
                <img :src="result.imageUrl" :alt="result.imageName" />
                <div class="defect-overlay">
                  <div 
                    v-for="defect in result.defects" 
                    :key="defect.id"
                    class="defect-box"
                    :style="getDefectBoxStyle(defect)"
                    :title="`${defect.type} (${(defect.confidence * 100).toFixed(1)}%)`"
                  >
                    <span class="defect-label">{{ defect.type }}</span>
                  </div>
                </div>
              </div>
              <div class="result-info">
                <div class="image-name">{{ result.imageName }}</div>
                <div class="defect-summary">
                  <el-tag 
                    v-for="defect in result.defectSummary" 
                    :key="defect.type"
                    :type="getDefectTagType(defect.type)"
                    size="small"
                    style="margin-right: 8px; margin-bottom: 4px;"
                  >
                    {{ defect.type }}: {{ defect.count }}
                  </el-tag>
                </div>
                <div class="result-meta">
                  <span>检测时间: {{ formatTime(result.detectTime) }}</span>
                  <span>处理时长: {{ result.processTime }}ms</span>
                </div>
              </div>
            </div>
            <!-- 新增：去审核按钮 -->
            <div class="go-next-wrapper">
              <el-button type="success" size="large" @click="goToAudit">
                <el-icon><Check /></el-icon>
                去审核
              </el-button>
            </div>
          </div>
          
          <!-- 空状态 -->
          <div v-else class="empty-result">
            <el-empty description="暂无检测结果">
              <template #image>
                <el-icon style="font-size: 60px; color: #c0c4cc;"><Search /></el-icon>
              </template>
              <template #description>
                <p>请先上传图片并开始检测</p>
              </template>
            </el-empty>
          </div>
        </el-card>
      </el-col>
    </el-row>

    <!-- 检测统计 -->
    <el-card class="stats-card" shadow="hover" style="margin-top: 20px;">
      <template #header>
        <span>检测统计</span>
      </template>
      
      <el-row :gutter="20">
        <el-col :span="6">
          <div class="stat-item">
            <div class="stat-number">{{ stats.totalImages }}</div>
            <div class="stat-label">检测图片数</div>
          </div>
        </el-col>
        <el-col :span="6">
          <div class="stat-item">
            <div class="stat-number">{{ stats.totalDefects }}</div>
            <div class="stat-label">发现缺陷数</div>
          </div>
        </el-col>
        <el-col :span="6">
          <div class="stat-item">
            <div class="stat-number">{{ stats.avgProcessTime }}ms</div>
            <div class="stat-label">平均处理时间</div>
          </div>
        </el-col>
        <el-col :span="6">
          <div class="stat-item">
            <div class="stat-number">{{ stats.defectRate }}%</div>
            <div class="stat-label">缺陷检出率</div>
          </div>
        </el-col>
      </el-row>
    </el-card>
  </div>
</template>

<script setup>
import { ref, reactive, computed, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { ElMessage } from 'element-plus'
import { Upload, Download, Delete, Search, Check } from '@element-plus/icons-vue'
import { useDetectStore } from '@/stores/detect'

// 检测配置
const detectConfig = reactive({
  model: 'yolov8',
  confidence: 0.5,
  nms: 0.4,
  defectTypes: ['crack', 'scratch', 'stain'],
  mode: 'single'
})

// 上传相关
const uploadRef = ref()
const uploadedFiles = ref([])
const detecting = ref(false)
const detectionProgress = ref(0)
const currentImageIndex = ref(0)

// 检测结果
const detectionResults = ref([])

// 统计数据
const stats = reactive({
  totalImages: 0,
  totalDefects: 0,
  avgProcessTime: 0,
  defectRate: 0
})

// 计算属性
const hasImages = computed(() => uploadedFiles.value.length > 0 || selectedImages.value.length > 0)
const hasResults = computed(() => detectionResults.value.length > 0)

// 文件上传处理
const handleFileChange = (file, fileList) => {
  uploadedFiles.value = fileList
}

const handleFileRemove = (file, fileList) => {
  uploadedFiles.value = fileList
}

const beforeUpload = (file) => {
  const isImage = file.type.startsWith('image/')
  const isLt10M = file.size / 1024 / 1024 < 10

  if (!isImage) {
    ElMessage.error('只能上传图片文件!')
    return false
  }
  if (!isLt10M) {
    ElMessage.error('图片大小不能超过 10MB!')
    return false
  }
  return false // 阻止自动上传
}

// 开始检测
const startDetection = async () => {
  if (!hasImages.value) {
    ElMessage.warning('请先上传图片或选择图片')
    return
  }

  detecting.value = true
  detectionProgress.value = 0
  currentImageIndex.value = 0
  detectionResults.value = []

  try {
    for (let i = 0; i < uploadedFiles.value.length; i++) {
      currentImageIndex.value = i
      detectionProgress.value = ((i + 1) / uploadedFiles.value.length) * 100
      
      // 模拟检测过程
      await new Promise(resolve => setTimeout(resolve, 1000))
      
      const file = uploadedFiles.value[i]
      const result = await simulateDetection(file)
      detectionResults.value.push(result)
    }
    
    ElMessage.success('检测完成')
    updateStats()
    detectStore.setDetectionResults(detectionResults.value)
  } catch (error) {
    ElMessage.error('检测失败，请重试')
  } finally {
    detecting.value = false
    detectionProgress.value = 0
  }
}

// 模拟检测过程
const simulateDetection = async (file) => {
  const imageUrl = URL.createObjectURL(file.raw)
  const startTime = Date.now()
  
  // 模拟检测延迟
  await new Promise(resolve => setTimeout(resolve, 800))
  
  const processTime = Date.now() - startTime
  
  // 模拟检测结果
  const defects = []
  const defectTypes = ['crack', 'scratch', 'stain', 'dent', 'color']
  const numDefects = Math.floor(Math.random() * 5)
  
  for (let i = 0; i < numDefects; i++) {
    defects.push({
      id: i,
      type: defectTypes[Math.floor(Math.random() * defectTypes.length)],
      confidence: 0.5 + Math.random() * 0.5,
      bbox: [
        Math.random() * 0.8,
        Math.random() * 0.8,
        Math.random() * 0.2 + 0.1,
        Math.random() * 0.2 + 0.1
      ]
    })
  }
  
  // 统计缺陷类型
  const defectSummary = {}
  defects.forEach(defect => {
    defectSummary[defect.type] = (defectSummary[defect.type] || 0) + 1
  })
  
  return {
    id: Date.now() + Math.random(),
    imageName: file.name,
    imageUrl,
    defects,
    defectSummary: Object.entries(defectSummary).map(([type, count]) => ({ type, count })),
    detectTime: new Date(),
    processTime
  }
}

// 更新统计
const updateStats = () => {
  stats.totalImages = detectionResults.value.length
  stats.totalDefects = detectionResults.value.reduce((sum, result) => sum + result.defects.length, 0)
  stats.avgProcessTime = Math.round(
    detectionResults.value.reduce((sum, result) => sum + result.processTime, 0) / detectionResults.value.length
  )
  stats.defectRate = Math.round((detectionResults.value.filter(r => r.defects.length > 0).length / detectionResults.value.length) * 100)
}

// 工具方法
const progressFormat = (percentage) => {
  return `${Math.round(percentage)}%`
}

const getDefectBoxStyle = (defect) => {
  const [x, y, w, h] = defect.bbox
  return {
    left: `${x * 100}%`,
    top: `${y * 100}%`,
    width: `${w * 100}%`,
    height: `${h * 100}%`
  }
}

const getDefectTagType = (type) => {
  const typeMap = {
    crack: 'danger',
    scratch: 'warning',
    stain: 'info',
    dent: 'error',
    color: 'success'
  }
  return typeMap[type] || 'info'
}

const formatTime = (time) => {
  return new Date(time).toLocaleString('zh-CN')
}

const clearImages = () => {
  uploadedFiles.value = []
  uploadRef.value?.clearFiles()
}

// 处理从图像管理传递的图片
const selectedImages = ref([])

const clearSelectedImages = () => {
  selectedImages.value = []
  detectStore.clearSelectedImages()
}

const toggleImageSelection = (image) => {
  image.selected = !image.selected
}

const formatFileSize = (bytes) => {
  if (bytes === 0) return '0 B'
  const k = 1024
  const sizes = ['B', 'KB', 'MB', 'GB']
  const i = Math.floor(Math.log(bytes) / Math.log(k))
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i]
}

// 监听 store 中的选中图片
onMounted(() => {
  console.log('缺陷检测页面加载完成')
  
  // 检查是否有从图像管理传递的图片
  const storeSelectedImages = detectStore.selectedImages
  if (storeSelectedImages && storeSelectedImages.length > 0) {
    selectedImages.value = storeSelectedImages.map(img => ({
      ...img,
      selected: true
    }))
  }
})

const clearResults = () => {
  detectionResults.value = []
  stats.totalImages = 0
  stats.totalDefects = 0
  stats.avgProcessTime = 0
  stats.defectRate = 0
}

const exportResults = () => {
  ElMessage.success('结果导出功能开发中...')
}

const router = useRouter()
const detectStore = useDetectStore()

const goToAudit = () => {
  detectStore.setDetectionResults(detectionResults.value)
  router.push('/audit')
}

onMounted(() => {
  console.log('缺陷检测页面加载完成')
})
</script>

<style lang="scss" scoped>
.page-header {
  margin-bottom: 24px;
  
  .subtitle {
    color: #666;
    margin-top: 8px;
    font-size: 14px;
  }
}

.config-card {
  .el-form-item {
    margin-bottom: 20px;
  }
}

.upload-card {
  .image-uploader {
    width: 100%;
    
    .el-upload-dragger {
      width: 100%;
      height: 180px;
    }
  }
  
  .upload-actions {
    text-align: center;
  }
}

.result-card {
  .result-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    
    .result-actions {
      display: flex;
      gap: 8px;
    }
  }
  
  .detection-progress {
    padding: 20px;
    text-align: center;
    
    .progress-text {
      margin-top: 12px;
      color: #606266;
    }
  }
  
  .result-list {
    .result-item {
      display: flex;
      margin-bottom: 20px;
      padding: 16px;
      border: 1px solid #e4e7ed;
      border-radius: 8px;
      
      .result-image {
        position: relative;
        width: 200px;
        height: 150px;
        margin-right: 16px;
        border-radius: 8px;
        overflow: hidden;
        
        img {
          width: 100%;
          height: 100%;
          object-fit: cover;
        }
        
        .defect-overlay {
          position: absolute;
          top: 0;
          left: 0;
          width: 100%;
          height: 100%;
          
          .defect-box {
            position: absolute;
            border: 2px solid #f56c6c;
            background: rgba(245, 108, 108, 0.1);
            
            .defect-label {
              position: absolute;
              top: -20px;
              left: 0;
              background: #f56c6c;
              color: white;
              padding: 2px 6px;
              font-size: 10px;
              border-radius: 2px;
            }
          }
        }
      }
      
      .result-info {
        flex: 1;
        
        .image-name {
          font-weight: bold;
          margin-bottom: 8px;
          color: #303133;
        }
        
        .defect-summary {
          margin-bottom: 8px;
        }
        
        .result-meta {
          font-size: 12px;
          color: #909399;
          
          span {
            margin-right: 16px;
          }
        }
      }
    }
  }
  
  .empty-result {
    padding: 40px;
    text-align: center;
  }
}

.stats-card {
  .stat-item {
    text-align: center;
    padding: 20px;
    
    .stat-number {
      font-size: 24px;
      font-weight: bold;
      color: var(--primary-color);
      margin-bottom: 8px;
    }
    
    .stat-label {
      font-size: 14px;
      color: #606266;
    }
  }
}

.go-next-wrapper {
  margin-top: 32px;
  text-align: center;
}

// 选中图片样式
.selected-images {
  margin-bottom: 16px;
  
  .selected-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 12px;
    
    span {
      font-weight: 500;
      color: #303133;
    }
  }
  
  .image-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(120px, 1fr));
    gap: 12px;
    max-height: 200px;
    overflow-y: auto;
    
    .image-item {
      position: relative;
      border: 2px solid #e4e7ed;
      border-radius: 8px;
      overflow: hidden;
      cursor: pointer;
      transition: all 0.3s;
      
      &:hover {
        border-color: var(--primary-color);
        transform: translateY(-2px);
      }
      
      &.selected {
        border-color: var(--primary-color);
        box-shadow: 0 2px 8px rgba(125, 200, 255, 0.3);
      }
      
      img {
        width: 100%;
        height: 80px;
        object-fit: cover;
      }
      
      .image-info {
        padding: 8px;
        background: #f8f9fa;
        
        .image-name {
          display: block;
          font-size: 12px;
          color: #303133;
          margin-bottom: 4px;
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
        }
        
        .image-size {
          display: block;
          font-size: 10px;
          color: #909399;
        }
      }
    }
  }
}

// 响应式设计
@media (max-width: 768px) {
  .el-col {
    width: 100% !important;
    margin-bottom: 20px;
  }
  
  .result-item {
    flex-direction: column;
    
    .result-image {
      width: 100% !important;
      margin-right: 0 !important;
      margin-bottom: 12px;
    }
  }
}
</style> 