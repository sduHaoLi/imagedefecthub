from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
import uvicorn
import os
from dotenv import load_dotenv

# 加载环境变量
load_dotenv()

# 创建FastAPI应用
app = FastAPI(
    title="ImageDefectHub API",
    description="AI辅助图像缺陷识别与审核系统后端API",
    version="1.0.0"
)

# 配置CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # 生产环境应该指定具体域名
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# 导入路由模块
from api import auth, images, detect, audit, reports, users

# 注册路由
app.include_router(auth.router, prefix="/api/auth", tags=["认证"])
app.include_router(images.router, prefix="/api/images", tags=["图像管理"])
app.include_router(detect.router, prefix="/api/detect", tags=["缺陷检测"])
app.include_router(audit.router, prefix="/api/audit", tags=["缺陷审核"])
app.include_router(reports.router, prefix="/api/reports", tags=["报告生成"])
app.include_router(users.router, prefix="/api/user", tags=["用户管理"])

# 挂载静态文件目录
if os.path.exists("uploads"):
    app.mount("/uploads", StaticFiles(directory="uploads"), name="uploads")

@app.get("/")
async def root():
    return {"message": "ImageDefectHub API 服务运行正常", "version": "1.0.0"}

@app.get("/health")
async def health_check():
    return {"status": "healthy", "service": "ImageDefectHub API"}

if __name__ == "__main__":
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=8000,
        reload=True,
        log_level="info"
    ) 