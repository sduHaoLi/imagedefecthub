import { defineStore } from 'pinia'
export const useDefectStore = defineStore('defect', {
  state: () => ({
    defectList: [],
    params: {
      threshold: 0.5,
      minSize: 1.0
    }
  }),
  actions: {
    setDefectList(list) {
      this.defectList = list
    },
    setParams(params) {
      this.params = { ...this.params, ...params }
    }
  }
}) 