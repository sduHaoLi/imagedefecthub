<template>
  <div class="page-container">
    <!-- 页面标题 -->
    <div class="page-header">
      <h2>缺陷审核</h2>
      <p class="subtitle">审核AI检测结果，确保缺陷识别的准确性和一致性</p>
    </div>

    <!-- 筛选和操作栏 -->
    <el-card class="filter-card" shadow="hover" style="margin-bottom: 20px;">
      <el-row :gutter="20" align="middle">
        <el-col :span="6">
          <el-select v-model="filterStatus" placeholder="审核状态" style="width: 100%">
            <el-option label="全部" value="" />
            <el-option label="待审核" value="pending" />
            <el-option label="已通过" value="approved" />
            <el-option label="已拒绝" value="rejected" />
          </el-select>
        </el-col>
        <el-col :span="6">
          <el-select v-model="filterDefectType" placeholder="缺陷类型" style="width: 100%">
            <el-option label="全部" value="" />
            <el-option label="裂纹" value="crack" />
            <el-option label="划痕" value="scratch" />
            <el-option label="污渍" value="stain" />
            <el-option label="凹陷" value="dent" />
            <el-option label="色差" value="color" />
          </el-select>
        </el-col>
        <el-col :span="6">
          <el-date-picker
            v-model="filterDateRange"
            type="daterange"
            range-separator="至"
            start-placeholder="开始日期"
            end-placeholder="结束日期"
            style="width: 100%"
          />
        </el-col>
        <el-col :span="6">
          <el-input
            v-model="searchKeyword"
            placeholder="搜索图片名称"
            clearable
            style="width: 100%"
          >
            <template #prefix>
              <el-icon><Search /></el-icon>
            </template>
          </el-input>
        </el-col>
      </el-row>
      
      <el-row style="margin-top: 16px;">
        <el-col :span="24">
          <el-button type="primary" @click="refreshList">
            <el-icon><Refresh /></el-icon>
            刷新
          </el-button>
          <el-button @click="resetFilter">重置筛选</el-button>
          <el-button type="success" @click="batchApprove" :disabled="!hasSelected">
            批量通过
          </el-button>
          <el-button type="danger" @click="batchReject" :disabled="!hasSelected">
            批量拒绝
          </el-button>
        </el-col>
      </el-row>
    </el-card>

    <!-- 审核列表 -->
    <el-card class="audit-list-card" shadow="hover">
      <template #header>
        <div class="list-header">
          <span>审核列表 ({{ filteredList.length }})</span>
          <div class="header-actions">
            <el-button size="small" @click="exportAuditData">
              <el-icon><Download /></el-icon>
              导出数据
            </el-button>
          </div>
        </div>
      </template>

      <!-- 加载状态 -->
      <div v-if="loading" class="loading-container">
        <el-skeleton :rows="5" animated />
      </div>

      <!-- 空状态 -->
      <div v-else-if="filteredList.length === 0" class="empty-state">
        <el-empty description="暂无审核数据">
          <template #image>
            <el-icon style="font-size: 60px; color: #c0c4cc;"><Check /></el-icon>
          </template>
        </el-empty>
      </div>

      <!-- 审核列表 -->
      <div v-else class="audit-list">
        <div v-for="item in paginatedList" :key="item.id" class="audit-item">
          <div class="item-header">
            <div class="item-info">
              <span class="image-name">{{ item.imageName }}</span>
              <el-tag :type="getStatusType(item.status)" size="small">
                {{ getStatusText(item.status) }}
              </el-tag>
            </div>
            <div class="item-actions">
              <el-button size="small" @click="previewImage(item)">
                <el-icon><View /></el-icon>
                预览
              </el-button>
              <el-button 
                v-if="item.status === 'pending'"
                size="small" 
                type="success" 
                @click="approveItem(item)"
              >
                <el-icon><Check /></el-icon>
                通过
              </el-button>
              <el-button 
                v-if="item.status === 'pending'"
                size="small" 
                type="danger" 
                @click="rejectItem(item)"
              >
                <el-icon><Close /></el-icon>
                拒绝
              </el-button>
            </div>
          </div>

          <div class="item-content">
            <div class="image-preview">
              <img :src="item.imageUrl" :alt="item.imageName" />
              <div class="defect-overlay">
                <div 
                  v-for="defect in item.defects" 
                  :key="defect.id"
                  class="defect-box"
                  :class="{ 'approved': defect.auditStatus === 'approved', 'rejected': defect.auditStatus === 'rejected' }"
                  :style="getDefectBoxStyle(defect)"
                >
                  <span class="defect-label">{{ defect.type }}</span>
                </div>
              </div>
            </div>

            <div class="defect-details">
              <div class="defect-list">
                <div v-for="defect in item.defects" :key="defect.id" class="defect-item">
                  <div class="defect-info">
                    <el-tag :type="getDefectTagType(defect.type)" size="small">
                      {{ defect.type }}
                    </el-tag>
                    <span class="confidence">置信度: {{ (defect.confidence * 100).toFixed(1) }}%</span>
                  </div>
                  <div class="defect-actions">
                    <el-button 
                      v-if="defect.auditStatus === 'pending'"
                      size="small" 
                      type="success" 
                      @click="approveDefect(item, defect)"
                    >
                      通过
                    </el-button>
                    <el-button 
                      v-if="defect.auditStatus === 'pending'"
                      size="small" 
                      type="danger" 
                      @click="rejectDefect(item, defect)"
                    >
                      拒绝
                    </el-button>
                    <el-tag 
                      v-else 
                      :type="defect.auditStatus === 'approved' ? 'success' : 'danger'"
                      size="small"
                    >
                      {{ defect.auditStatus === 'approved' ? '已通过' : '已拒绝' }}
                    </el-tag>
                  </div>
                </div>
              </div>

              <div class="item-meta">
                <div class="meta-item">
                  <span class="label">检测时间:</span>
                  <span>{{ formatTime(item.detectTime) }}</span>
                </div>
                <div class="meta-item">
                  <span class="label">检测模型:</span>
                  <span>{{ item.model }}</span>
                </div>
                <div class="meta-item">
                  <span class="label">缺陷数量:</span>
                  <span>{{ item.defects.length }}</span>
                </div>
              </div>

              <div class="audit-notes">
                <el-input
                  v-model="item.notes"
                  type="textarea"
                  :rows="2"
                  placeholder="添加审核备注..."
                  @blur="saveNotes(item)"
                />
              </div>
            </div>
          </div>
        </div>
        <!-- 新增：生成报告按钮 -->
        <div v-if="allAudited" class="go-next-wrapper">
          <el-button type="primary" size="large" @click="goToReport">
            <el-icon><Document /></el-icon>
            生成报告
          </el-button>
        </div>
      </div>

      <!-- 分页 -->
      <div class="pagination-wrapper" v-if="filteredList.length > 0">
        <el-pagination
          v-model:current-page="currentPage"
          v-model:page-size="pageSize"
          :page-sizes="[10, 20, 50, 100]"
          :total="filteredList.length"
          layout="total, sizes, prev, pager, next, jumper"
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
        />
      </div>
    </el-card>

    <!-- 图片预览对话框 -->
    <el-dialog
      v-model="previewVisible"
      title="图片预览"
      width="80%"
      destroy-on-close
    >
      <div class="preview-container">
        <img :src="previewImageUrl" :alt="previewImageName" class="preview-image" />
      </div>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, reactive, computed, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { ElMessage, ElMessageBox } from 'element-plus'
import { Search, Refresh, Download, View, Check, Close, Document } from '@element-plus/icons-vue'

// 筛选条件
const filterStatus = ref('')
const filterDefectType = ref('')
const filterDateRange = ref([])
const searchKeyword = ref('')

// 列表数据
const auditList = ref([])
const loading = ref(false)
const selectedItems = ref([])

// 分页
const currentPage = ref(1)
const pageSize = ref(10)

// 预览
const previewVisible = ref(false)
const previewImageUrl = ref('')
const previewImageName = ref('')

// 计算属性
const filteredList = computed(() => {
  let list = [...auditList.value]
  
  if (filterStatus.value) {
    list = list.filter(item => item.status === filterStatus.value)
  }
  
  if (filterDefectType.value) {
    list = list.filter(item => 
      item.defects.some(defect => defect.type === filterDefectType.value)
    )
  }
  
  if (searchKeyword.value) {
    list = list.filter(item => 
      item.imageName.toLowerCase().includes(searchKeyword.value.toLowerCase())
    )
  }
  
  return list
})

const paginatedList = computed(() => {
  const start = (currentPage.value - 1) * pageSize.value
  const end = start + pageSize.value
  return filteredList.value.slice(start, end)
})

const hasSelected = computed(() => selectedItems.value.length > 0)

const allAudited = computed(() => {
  return filteredList.value.length > 0 && filteredList.value.every(item => item.status !== 'pending')
})

const goToReport = () => {
  router.push('/report-center')
}

// 初始化数据
const initData = () => {
  // 模拟审核数据
  auditList.value = [
    {
      id: 1,
      imageName: 'product_001.jpg',
      imageUrl: 'https://picsum.photos/400/300?random=1',
      status: 'pending',
      model: 'YOLOv8',
      detectTime: new Date('2024-01-15T10:30:00Z'),
      defects: [
        { id: 1, type: 'crack', confidence: 0.85, auditStatus: 'pending', bbox: [0.1, 0.2, 0.3, 0.2] },
        { id: 2, type: 'scratch', confidence: 0.72, auditStatus: 'pending', bbox: [0.5, 0.6, 0.2, 0.1] }
      ],
      notes: ''
    },
    {
      id: 2,
      imageName: 'product_002.png',
      imageUrl: 'https://picsum.photos/400/300?random=2',
      status: 'approved',
      model: 'YOLOv8',
      detectTime: new Date('2024-01-15T11:20:00Z'),
      defects: [
        { id: 3, type: 'stain', confidence: 0.91, auditStatus: 'approved', bbox: [0.2, 0.3, 0.25, 0.15] }
      ],
      notes: '确认存在污渍缺陷'
    },
    {
      id: 3,
      imageName: 'product_003.jpg',
      imageUrl: 'https://picsum.photos/400/300?random=3',
      status: 'rejected',
      model: 'YOLOv8',
      detectTime: new Date('2024-01-15T14:15:00Z'),
      defects: [
        { id: 4, type: 'crack', confidence: 0.45, auditStatus: 'rejected', bbox: [0.3, 0.4, 0.2, 0.1] }
      ],
      notes: '误检，实际为正常纹理'
    }
  ]
}

// 工具方法
const getStatusType = (status) => {
  const typeMap = {
    pending: 'warning',
    approved: 'success',
    rejected: 'danger'
  }
  return typeMap[status] || 'info'
}

const getStatusText = (status) => {
  const textMap = {
    pending: '待审核',
    approved: '已通过',
    rejected: '已拒绝'
  }
  return textMap[status] || '未知'
}

const getDefectTagType = (type) => {
  const typeMap = {
    crack: 'danger',
    scratch: 'warning',
    stain: 'info',
    dent: 'error',
    color: 'success'
  }
  return typeMap[type] || 'info'
}

const getDefectBoxStyle = (defect) => {
  const [x, y, w, h] = defect.bbox
  return {
    left: `${x * 100}%`,
    top: `${y * 100}%`,
    width: `${w * 100}%`,
    height: `${h * 100}%`
  }
}

const formatTime = (time) => {
  return new Date(time).toLocaleString('zh-CN')
}

// 操作方法
const refreshList = async () => {
  loading.value = true
  try {
    await new Promise(resolve => setTimeout(resolve, 1000))
    initData()
    ElMessage.success('刷新成功')
  } catch (error) {
    ElMessage.error('刷新失败')
  } finally {
    loading.value = false
  }
}

const resetFilter = () => {
  filterStatus.value = ''
  filterDefectType.value = ''
  filterDateRange.value = []
  searchKeyword.value = ''
  currentPage.value = 1
}

const previewImage = (item) => {
  previewImageUrl.value = item.imageUrl
  previewImageName.value = item.imageName
  previewVisible.value = true
}

const approveItem = async (item) => {
  try {
    await ElMessageBox.confirm('确定通过这张图片的审核吗？', '确认操作', {
      confirmButtonText: '确定',
      cancelButtonText: '取消',
      type: 'warning'
    })
    
    item.status = 'approved'
    item.defects.forEach(defect => {
      if (defect.auditStatus === 'pending') {
        defect.auditStatus = 'approved'
      }
    })
    
    ElMessage.success('审核通过')
  } catch {
    // 用户取消
  }
}

const rejectItem = async (item) => {
  try {
    await ElMessageBox.confirm('确定拒绝这张图片的审核吗？', '确认操作', {
      confirmButtonText: '确定',
      cancelButtonText: '取消',
      type: 'warning'
    })
    
    item.status = 'rejected'
    item.defects.forEach(defect => {
      if (defect.auditStatus === 'pending') {
        defect.auditStatus = 'rejected'
      }
    })
    
    ElMessage.success('审核拒绝')
  } catch {
    // 用户取消
  }
}

const approveDefect = (item, defect) => {
  defect.auditStatus = 'approved'
  // 检查是否所有缺陷都已审核
  const allReviewed = item.defects.every(d => d.auditStatus !== 'pending')
  if (allReviewed) {
    const hasRejected = item.defects.some(d => d.auditStatus === 'rejected')
    item.status = hasRejected ? 'rejected' : 'approved'
  }
  ElMessage.success('缺陷审核通过')
}

const rejectDefect = (item, defect) => {
  defect.auditStatus = 'rejected'
  // 检查是否所有缺陷都已审核
  const allReviewed = item.defects.every(d => d.auditStatus !== 'pending')
  if (allReviewed) {
    item.status = 'rejected'
  }
  ElMessage.success('缺陷审核拒绝')
}

const saveNotes = (item) => {
  // 这里可以调用API保存备注
  console.log('保存备注:', item.notes)
}

const batchApprove = async () => {
  try {
    await ElMessageBox.confirm(`确定批量通过 ${selectedItems.value.length} 项审核吗？`, '批量操作', {
      confirmButtonText: '确定',
      cancelButtonText: '取消',
      type: 'warning'
    })
    
    selectedItems.value.forEach(id => {
      const item = auditList.value.find(item => item.id === id)
      if (item && item.status === 'pending') {
        approveItem(item)
      }
    })
    
    selectedItems.value = []
    ElMessage.success('批量操作完成')
  } catch {
    // 用户取消
  }
}

const batchReject = async () => {
  try {
    await ElMessageBox.confirm(`确定批量拒绝 ${selectedItems.value.length} 项审核吗？`, '批量操作', {
      confirmButtonText: '确定',
      cancelButtonText: '取消',
      type: 'warning'
    })
    
    selectedItems.value.forEach(id => {
      const item = auditList.value.find(item => item.id === id)
      if (item && item.status === 'pending') {
        rejectItem(item)
      }
    })
    
    selectedItems.value = []
    ElMessage.success('批量操作完成')
  } catch {
    // 用户取消
  }
}

const exportAuditData = () => {
  ElMessage.success('导出功能开发中...')
}

// 分页处理
const handleSizeChange = (val) => {
  pageSize.value = val
  currentPage.value = 1
}

const handleCurrentChange = (val) => {
  currentPage.value = val
}

onMounted(() => {
  initData()
  console.log('缺陷审核页面加载完成')
})
</script>

<style lang="scss" scoped>
.page-header {
  margin-bottom: 24px;
  
  .subtitle {
    color: #666;
    margin-top: 8px;
    font-size: 14px;
  }
}

.filter-card {
  .el-row {
    align-items: center;
  }
}

.audit-list-card {
  .list-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    
    .header-actions {
      display: flex;
      gap: 8px;
    }
  }
  
  .loading-container {
    padding: 20px;
  }
  
  .empty-state {
    padding: 40px;
    text-align: center;
  }
  
  .audit-list {
    .audit-item {
      border: 1px solid #e4e7ed;
      border-radius: 8px;
      margin-bottom: 16px;
      overflow: hidden;
      
      .item-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 12px 16px;
        background: #f8f9fa;
        border-bottom: 1px solid #e4e7ed;
        
        .item-info {
          display: flex;
          align-items: center;
          gap: 12px;
          
          .image-name {
            font-weight: bold;
            color: #303133;
          }
        }
        
        .item-actions {
          display: flex;
          gap: 8px;
        }
      }
      
      .item-content {
        display: flex;
        padding: 16px;
        
        .image-preview {
          position: relative;
          width: 200px;
          height: 150px;
          margin-right: 16px;
          border-radius: 8px;
          overflow: hidden;
          flex-shrink: 0;
          
          img {
            width: 100%;
            height: 100%;
            object-fit: cover;
          }
          
          .defect-overlay {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            
            .defect-box {
              position: absolute;
              border: 2px solid #f56c6c;
              background: rgba(245, 108, 108, 0.1);
              
              &.approved {
                border-color: #67c23a;
                background: rgba(103, 194, 58, 0.1);
              }
              
              &.rejected {
                border-color: #909399;
                background: rgba(144, 147, 153, 0.1);
              }
              
              .defect-label {
                position: absolute;
                top: -20px;
                left: 0;
                background: #f56c6c;
                color: white;
                padding: 2px 6px;
                font-size: 10px;
                border-radius: 2px;
              }
            }
          }
        }
        
        .defect-details {
          flex: 1;
          
          .defect-list {
            margin-bottom: 16px;
            
            .defect-item {
              display: flex;
              justify-content: space-between;
              align-items: center;
              padding: 8px 0;
              border-bottom: 1px solid #f0f0f0;
              
              &:last-child {
                border-bottom: none;
              }
              
              .defect-info {
                display: flex;
                align-items: center;
                gap: 12px;
                
                .confidence {
                  font-size: 12px;
                  color: #909399;
                }
              }
              
              .defect-actions {
                display: flex;
                gap: 8px;
              }
            }
          }
          
          .item-meta {
            margin-bottom: 16px;
            
            .meta-item {
              display: flex;
              margin-bottom: 4px;
              
              .label {
                font-weight: bold;
                color: #606266;
                margin-right: 8px;
                min-width: 80px;
              }
            }
          }
          
          .audit-notes {
            .el-textarea {
              font-size: 12px;
            }
          }
        }
      }
    }
  }
  
  .pagination-wrapper {
    margin-top: 20px;
    text-align: center;
  }
}

.preview-container {
  text-align: center;
  
  .preview-image {
    max-width: 100%;
    max-height: 500px;
    border-radius: 8px;
  }
}

.go-next-wrapper {
  margin-top: 32px;
  text-align: center;
}

// 响应式设计
@media (max-width: 768px) {
  .filter-card {
    .el-col {
      margin-bottom: 12px;
    }
  }
  
  .audit-item {
    .item-content {
      flex-direction: column;
      
      .image-preview {
        width: 100% !important;
        margin-right: 0 !important;
        margin-bottom: 16px;
      }
    }
  }
}
</style> 