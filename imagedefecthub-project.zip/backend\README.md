# ImageDefectHub 后端服务

基于 FastAPI + YOLO 的 AI 辅助图像缺陷识别与审核系统后端服务。

## 🚀 快速开始

### 1. 环境要求

- Python 3.8+
- MySQL 5.7+ 或 PostgreSQL
- Redis (可选，用于缓存)

### 2. 安装依赖

```bash
# 进入后端目录
cd backend

# 创建虚拟环境
python -m venv venv

# 激活虚拟环境
# Windows
venv\Scripts\activate
# Linux/Mac
source venv/bin/activate

# 安装依赖
pip install -r requirements.txt
```

### 3. 配置环境变量

```bash
# 复制环境变量示例文件
cp env.example .env

# 编辑 .env 文件，配置数据库连接等信息
```

### 4. 数据库配置

#### MySQL 配置示例：
```sql
-- 创建数据库
CREATE DATABASE imagedefecthub CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- 创建用户（可选）
CREATE USER 'imagedefecthub'@'localhost' IDENTIFIED BY 'your_password';
GRANT ALL PRIVILEGES ON imagedefecthub.* TO 'imagedefecthub'@'localhost';
FLUSH PRIVILEGES;
```

#### 环境变量配置：
```env
DATABASE_URL=mysql+pymysql://username:password@localhost:3306/imagedefecthub
```

### 5. 启动服务

```bash
# 方式一：使用启动脚本
python start.py

# 方式二：直接启动
uvicorn main:app --host 0.0.0.0 --port 8000 --reload
```

### 6. 访问服务

- API 服务：http://localhost:8000
- API 文档：http://localhost:8000/docs
- 交互式文档：http://localhost:8000/redoc

## 📁 项目结构

```
backend/
├── main.py                 # FastAPI 主应用
├── config.py              # 配置文件
├── requirements.txt        # Python 依赖
├── start.py              # 启动脚本
├── env.example           # 环境变量示例
├── README.md             # 项目说明
├── api/                  # API 路由模块
│   ├── auth.py          # 认证相关
│   ├── images.py        # 图像管理
│   ├── detect.py        # 缺陷检测
│   ├── audit.py         # 缺陷审核
│   ├── reports.py       # 报告生成
│   └── users.py         # 用户管理
├── models/              # 数据模型
│   └── database.py      # 数据库模型
├── utils/               # 工具模块
│   ├── auth.py          # 认证工具
│   └── yolo_detector.py # YOLO 检测器
├── uploads/             # 上传文件目录
├── reports/             # 报告文件目录
└── models/              # YOLO 模型目录
```

## 🔧 API 接口

### 认证相关
- `POST /api/auth/login` - 用户登录
- `POST /api/auth/register` - 用户注册
- `POST /api/auth/logout` - 用户登出
- `GET /api/auth/verify` - 验证令牌

### 图像管理
- `POST /api/images/upload` - 上传图片
- `GET /api/images/list` - 获取图片列表
- `GET /api/images/{image_id}` - 获取图片详情
- `DELETE /api/images/{image_id}` - 删除图片
- `DELETE /api/images/batch` - 批量删除图片
- `GET /api/images/statistics` - 获取图片统计

### 缺陷检测
- `POST /api/detect/single` - 单张图片检测
- `POST /api/detect/batch` - 批量图片检测
- `GET /api/detect/config` - 获取检测配置
- `POST /api/detect/config` - 更新检测配置
- `GET /api/detect/model-info` - 获取模型信息

### 缺陷审核
- `GET /api/audit/list` - 获取审核列表
- `POST /api/audit/{audit_id}` - 更新审核状态
- `POST /api/audit/batch` - 批量审核
- `GET /api/audit/statistics` - 获取审核统计
- `GET /api/audit/pending-count` - 获取待审核数量

### 报告生成
- `POST /api/reports/generate` - 生成报告
- `GET /api/reports/download/{report_id}` - 下载报告
- `GET /api/reports/history` - 获取报告历史

### 用户管理
- `GET /api/user/info` - 获取用户信息
- `PUT /api/user/update` - 更新用户信息
- `POST /api/user/change-password` - 修改密码
- `POST /api/user/upload-avatar` - 上传头像
- `GET /api/user/statistics` - 获取用户统计

## 🤖 YOLO 模型配置

### 1. 模型文件
将训练好的 YOLO 模型文件放在 `models/` 目录下：
```
models/
└── best.pt  # 你的训练模型
```

### 2. 环境变量配置
```env
MODEL_PATH=models/best.pt
CONFIDENCE_THRESHOLD=0.5
NMS_THRESHOLD=0.4
```

### 3. 使用预训练模型
如果没有训练好的模型，系统会自动使用 YOLOv8n 预训练模型。

## 🔒 安全配置

### 1. JWT 密钥
生产环境中请修改 JWT 密钥：
```env
SECRET_KEY=your-very-secure-secret-key-here
```

### 2. CORS 配置
在 `main.py` 中配置允许的域名：
```python
allow_origins=["http://localhost:3000", "https://yourdomain.com"]
```

### 3. 文件上传限制
```env
MAX_FILE_SIZE=10485760  # 10MB
```

## 📊 数据库表结构

### users 表
- id: 用户ID
- username: 用户名
- email: 邮箱
- hashed_password: 加密密码
- full_name: 姓名
- avatar_url: 头像URL
- is_active: 是否激活
- created_at: 创建时间
- updated_at: 更新时间

### images 表
- id: 图片ID
- filename: 文件名
- original_name: 原始文件名
- file_path: 文件路径
- file_size: 文件大小
- file_type: 文件类型
- width: 图片宽度
- height: 图片高度
- user_id: 上传用户ID
- uploaded_at: 上传时间

### detection_results 表
- id: 检测结果ID
- image_id: 图片ID
- defect_type: 缺陷类型
- confidence: 置信度
- bbox_x: 边界框X坐标
- bbox_y: 边界框Y坐标
- bbox_width: 边界框宽度
- bbox_height: 边界框高度
- model_version: 模型版本
- detected_at: 检测时间

### audit_records 表
- id: 审核记录ID
- image_id: 图片ID
- user_id: 审核用户ID
- detection_result_id: 检测结果ID
- audit_status: 审核状态
- notes: 备注
- audited_at: 审核时间

### reports 表
- id: 报告ID
- report_name: 报告名称
- report_type: 报告类型
- file_path: 文件路径
- file_size: 文件大小
- generated_by: 生成用户ID
- generated_at: 生成时间
- parameters: 参数（JSON）

## 🚀 部署

### 1. 生产环境配置
```env
DEBUG=False
HOST=0.0.0.0
PORT=8000
```

### 2. 使用 Gunicorn 部署
```bash
pip install gunicorn
gunicorn main:app -w 4 -k uvicorn.workers.UvicornWorker --bind 0.0.0.0:8000
```

### 3. Docker 部署
```dockerfile
FROM python:3.9-slim

WORKDIR /app
COPY requirements.txt .
RUN pip install -r requirements.txt

COPY . .

EXPOSE 8000
CMD ["uvicorn", "main:app", "--host", "0.0.0.0", "--port", "8000"]
```

## 🔧 故障排除

### 1. 数据库连接失败
- 检查数据库服务是否启动
- 验证数据库连接字符串
- 确认数据库用户权限

### 2. YOLO 模型加载失败
- 检查模型文件是否存在
- 确认模型文件格式正确
- 查看错误日志

### 3. 文件上传失败
- 检查上传目录权限
- 确认文件大小限制
- 验证文件格式

### 4. API 请求失败
- 检查 CORS 配置
- 验证 JWT 令牌
- 查看服务器日志

## 📞 技术支持

如有问题，请查看：
1. API 文档：http://localhost:8000/docs
2. 服务器日志
3. 数据库连接状态

## �� 许可证

MIT License 