import axios from 'axios'
import { ElMessage } from 'element-plus'

const service = axios.create({
  baseURL: '/api',
  timeout: 15000
})

// 请求拦截器
service.interceptors.request.use(
  config => {
    // 可以在这里添加token等认证信息
    return config
  },
  error => {
    console.error('请求错误：', error)
    return Promise.reject(error)
  }
)

// 响应拦截器
service.interceptors.response.use(
  response => {
    const res = response.data
    
    if (res.code !== 200) {
      ElMessage({
        message: res.message || '请求失败',
        type: 'error',
        duration: 3000
      })
      return Promise.reject(res)
    }
    return res.data
  },
  error => {
    console.error('响应错误：', error)
    
    // 如果是网络错误或连接被拒绝，不显示错误消息，避免白屏
    if (error.code === 'ECONNREFUSED' || error.message.includes('Failed to fetch') || error.message.includes('Network Error')) {
      console.warn('API 服务未运行，使用模拟数据')
      return Promise.resolve({ 
        code: 200, 
        data: null, 
        message: 'API 服务未运行，使用模拟数据' 
      })
    }
    
    ElMessage({
      message: error.message || '网络错误',
      type: 'error',
      duration: 3000
    })
    return Promise.reject(error)
  }
)

export default service 