<template>
  <el-upload
    class="image-uploader"
    drag
    multiple
    :limit="50"
    :auto-upload="false"
    :on-change="handleChange"
    :file-list="fileList"
    accept=".jpg,.jpeg,.png,.bmp"
  >
    <i class="el-icon-upload"></i>
    <div class="el-upload__text">拖拽图片到此处，或 <em>点击上传</em></div>
    <div class="el-upload__tip">支持JPG/PNG/BMP格式，最多50张/次</div>
  </el-upload>
</template>
<script setup>
import { ref } from 'vue'
const fileList = ref([])
function handleChange(file, fileList_) {
  fileList.value = fileList_
  // 后续补充上传逻辑
}
</script>
<style scoped>
.image-uploader {
  margin-bottom: 16px;
}
</style> 