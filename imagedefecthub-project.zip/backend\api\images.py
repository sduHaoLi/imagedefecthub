from fastapi import APIRouter, File, UploadFile, HTTPException, Depends, Query
from fastapi.responses import JSONResponse
from typing import List, Optional
import os
import uuid
from datetime import datetime
from sqlalchemy.orm import Session
from PIL import Image as PILImage
import io

from models.database import get_db, Image, User
from utils.auth import get_current_user
from config import settings

router = APIRouter()

@router.post("/upload")
async def upload_image(
    file: UploadFile = File(...),
    db: Session = Depends(get_db)
):
    """上传图片"""
    try:
        # 验证文件类型
        if not file.filename.lower().endswith(tuple(settings.ALLOWED_EXTENSIONS)):
            raise HTTPException(status_code=400, detail="不支持的文件格式")
        
        # 读取文件内容
        image_data = await file.read()
        
        # 检查文件大小
        if len(image_data) > settings.MAX_FILE_SIZE:
            raise HTTPException(status_code=400, detail="文件大小超过限制")
        
        # 生成唯一文件名
        file_extension = os.path.splitext(file.filename)[1]
        filename = f"{uuid.uuid4()}{file_extension}"
        file_path = os.path.join(settings.UPLOAD_DIR, filename)
        
        # 确保上传目录存在
        os.makedirs(settings.UPLOAD_DIR, exist_ok=True)
        
        # 保存文件
        with open(file_path, "wb") as f:
            f.write(image_data)
        
        # 获取图片尺寸
        try:
            image = PILImage.open(io.BytesIO(image_data))
            width, height = image.size
        except:
            width, height = 0, 0
        
        # 保存到数据库
        db_image = Image(
            filename=filename,
            original_name=file.filename,
            file_path=file_path,
            file_size=len(image_data),
            file_type=file_extension[1:],
            width=width,
            height=height,
            user_id=1  # 暂时使用默认用户ID
        )
        
        db.add(db_image)
        db.commit()
        db.refresh(db_image)
        
        return JSONResponse(content={
            "code": 200,
            "message": "上传成功",
            "data": {
                "id": db_image.id,
                "filename": db_image.filename,
                "original_name": db_image.original_name,
                "file_path": f"/uploads/{filename}",
                "file_size": db_image.file_size,
                "width": db_image.width,
                "height": db_image.height,
                "uploaded_at": db_image.uploaded_at.isoformat()
            }
        })
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"上传失败: {str(e)}")

@router.get("/list")
async def get_image_list(
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    search: Optional[str] = Query(None),
    sort_by: str = Query("uploaded_at", regex="^(filename|original_name|file_size|uploaded_at)$"),
    sort_order: str = Query("desc", regex="^(asc|desc)$"),
    db: Session = Depends(get_db)
):
    """获取图片列表"""
    try:
        # 构建查询
        query = db.query(Image)
        
        # 搜索过滤
        if search:
            query = query.filter(Image.original_name.contains(search))
        
        # 排序
        if sort_order == "desc":
            query = query.order_by(getattr(Image, sort_by).desc())
        else:
            query = query.order_by(getattr(Image, sort_by).asc())
        
        # 分页
        total = query.count()
        images = query.offset((page - 1) * page_size).limit(page_size).all()
        
        # 格式化数据
        image_list = []
        for image in images:
            image_list.append({
                "id": image.id,
                "filename": image.filename,
                "original_name": image.original_name,
                "file_path": f"/uploads/{image.filename}",
                "file_size": image.file_size,
                "file_type": image.file_type,
                "width": image.width,
                "height": image.height,
                "uploaded_at": image.uploaded_at.isoformat()
            })
        
        return JSONResponse(content={
            "code": 200,
            "data": {
                "images": image_list,
                "pagination": {
                    "page": page,
                    "page_size": page_size,
                    "total": total,
                    "total_pages": (total + page_size - 1) // page_size
                }
            }
        })
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"获取图片列表失败: {str(e)}")

@router.get("/{image_id}")
async def get_image_detail(
    image_id: int,
    db: Session = Depends(get_db)
):
    """获取图片详情"""
    try:
        image = db.query(Image).filter(Image.id == image_id).first()
        
        if not image:
            raise HTTPException(status_code=404, detail="图片不存在")
        
        return JSONResponse(content={
            "code": 200,
            "data": {
                "id": image.id,
                "filename": image.filename,
                "original_name": image.original_name,
                "file_path": f"/uploads/{image.filename}",
                "file_size": image.file_size,
                "file_type": image.file_type,
                "width": image.width,
                "height": image.height,
                "uploaded_at": image.uploaded_at.isoformat()
            }
        })
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"获取图片详情失败: {str(e)}")

@router.delete("/{image_id}")
async def delete_image(
    image_id: int,
    db: Session = Depends(get_db)
):
    """删除图片"""
    try:
        image = db.query(Image).filter(Image.id == image_id).first()
        
        if not image:
            raise HTTPException(status_code=404, detail="图片不存在")
        
        # 删除文件
        file_path = image.file_path
        if os.path.exists(file_path):
            os.remove(file_path)
        
        # 删除数据库记录
        db.delete(image)
        db.commit()
        
        return JSONResponse(content={
            "code": 200,
            "message": "删除成功"
        })
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"删除失败: {str(e)}")

@router.delete("/batch")
async def delete_batch_images(
    image_ids: List[int],
    db: Session = Depends(get_db)
):
    """批量删除图片"""
    try:
        deleted_count = 0
        
        for image_id in image_ids:
            image = db.query(Image).filter(Image.id == image_id).first()
            
            if image:
                # 删除文件
                file_path = image.file_path
                if os.path.exists(file_path):
                    os.remove(file_path)
                
                # 删除数据库记录
                db.delete(image)
                deleted_count += 1
        
        db.commit()
        
        return JSONResponse(content={
            "code": 200,
            "message": f"批量删除成功，共删除 {deleted_count} 张图片"
        })
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"批量删除失败: {str(e)}")

@router.get("/statistics")
async def get_image_statistics(
    db: Session = Depends(get_db)
):
    """获取图片统计信息"""
    try:
        total_images = db.query(Image).count()
        total_size = db.query(Image).with_entities(db.func.sum(Image.file_size)).scalar() or 0
        
        # 按文件类型统计
        type_stats = db.query(
            Image.file_type,
            db.func.count(Image.id).label('count')
        ).group_by(Image.file_type).all()
        
        return JSONResponse(content={
            "code": 200,
            "data": {
                "total_images": total_images,
                "total_size": total_size,
                "type_statistics": [
                    {"type": stat.file_type, "count": stat.count}
                    for stat in type_stats
                ]
            }
        })
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"获取统计信息失败: {str(e)}") 