import { createApp } from 'vue'
import App from './App.vue'
import router from './router'
import { createPinia } from 'pinia'
import ElementPlus from 'element-plus'
import 'element-plus/dist/index.css'
import './style/index.scss'

const app = createApp(App)

// 注册全局组件
import ImageUploader from '@/components/ImageUploader.vue'
import DefectMarker from '@/components/DefectMarker.vue'
app.component('ImageUploader', ImageUploader)
app.component('DefectMarker', DefectMarker)

app.use(router)
   .use(createPinia())
   .use(ElementPlus)
   .mount('#app') 