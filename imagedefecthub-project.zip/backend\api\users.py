from fastapi import APIRouter, HTTPException, Depends, File, UploadFile
from fastapi.responses import JSONResponse
from pydantic import BaseModel
from typing import Optional
import os
import uuid
from sqlalchemy.orm import Session

from models.database import get_db, User
from utils.auth import get_current_user, get_password_hash, verify_password
from config import settings

router = APIRouter()

class UpdateUserRequest(BaseModel):
    full_name: Optional[str] = None
    email: Optional[str] = None

class ChangePasswordRequest(BaseModel):
    old_password: str
    new_password: str

@router.get("/info")
async def get_user_info(
    current_user: str = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """获取用户信息"""
    try:
        user = db.query(User).filter(User.username == current_user).first()
        
        if not user:
            raise HTTPException(status_code=404, detail="用户不存在")
        
        return JSONResponse(content={
            "code": 200,
            "data": {
                "id": user.id,
                "username": user.username,
                "email": user.email,
                "full_name": user.full_name,
                "avatar_url": user.avatar_url,
                "is_active": user.is_active,
                "created_at": user.created_at.isoformat(),
                "updated_at": user.updated_at.isoformat()
            }
        })
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"获取用户信息失败: {str(e)}")

@router.put("/update")
async def update_user_info(
    update_data: UpdateUserRequest,
    current_user: str = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """更新用户信息"""
    try:
        user = db.query(User).filter(User.username == current_user).first()
        
        if not user:
            raise HTTPException(status_code=404, detail="用户不存在")
        
        # 更新字段
        if update_data.full_name is not None:
            user.full_name = update_data.full_name
        
        if update_data.email is not None:
            # 检查邮箱是否已被其他用户使用
            existing_user = db.query(User).filter(
                User.email == update_data.email,
                User.id != user.id
            ).first()
            if existing_user:
                raise HTTPException(status_code=400, detail="邮箱已被使用")
            user.email = update_data.email
        
        db.commit()
        db.refresh(user)
        
        return JSONResponse(content={
            "code": 200,
            "message": "更新成功",
            "data": {
                "id": user.id,
                "username": user.username,
                "email": user.email,
                "full_name": user.full_name,
                "avatar_url": user.avatar_url
            }
        })
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"更新用户信息失败: {str(e)}")

@router.post("/change-password")
async def change_password(
    password_data: ChangePasswordRequest,
    current_user: str = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """修改密码"""
    try:
        user = db.query(User).filter(User.username == current_user).first()
        
        if not user:
            raise HTTPException(status_code=404, detail="用户不存在")
        
        # 验证旧密码
        if not verify_password(password_data.old_password, user.hashed_password):
            raise HTTPException(status_code=400, detail="原密码错误")
        
        # 更新密码
        user.hashed_password = get_password_hash(password_data.new_password)
        db.commit()
        
        return JSONResponse(content={
            "code": 200,
            "message": "密码修改成功"
        })
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"修改密码失败: {str(e)}")

@router.post("/upload-avatar")
async def upload_avatar(
    file: UploadFile = File(...),
    current_user: str = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """上传头像"""
    try:
        # 验证文件类型
        allowed_types = {".jpg", ".jpeg", ".png", ".gif"}
        file_extension = os.path.splitext(file.filename)[1].lower()
        
        if file_extension not in allowed_types:
            raise HTTPException(status_code=400, detail="不支持的文件格式")
        
        # 检查文件大小（限制为2MB）
        file_content = await file.read()
        if len(file_content) > 2 * 1024 * 1024:
            raise HTTPException(status_code=400, detail="文件大小超过限制")
        
        # 生成文件名
        filename = f"avatar_{uuid.uuid4()}{file_extension}"
        file_path = os.path.join(settings.UPLOAD_DIR, "avatars", filename)
        
        # 确保目录存在
        os.makedirs(os.path.dirname(file_path), exist_ok=True)
        
        # 保存文件
        with open(file_path, "wb") as f:
            f.write(file_content)
        
        # 更新用户头像
        user = db.query(User).filter(User.username == current_user).first()
        if user:
            user.avatar_url = f"/uploads/avatars/{filename}"
            db.commit()
        
        return JSONResponse(content={
            "code": 200,
            "message": "头像上传成功",
            "data": {
                "avatar_url": f"/uploads/avatars/{filename}"
            }
        })
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"头像上传失败: {str(e)}")

@router.get("/statistics")
async def get_user_statistics(
    current_user: str = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """获取用户统计信息"""
    try:
        user = db.query(User).filter(User.username == current_user).first()
        
        if not user:
            raise HTTPException(status_code=404, detail="用户不存在")
        
        # 统计用户上传的图片数量
        image_count = db.query(User).filter(User.id == user.id).count()
        
        # 统计审核记录数量
        audit_count = db.query(User).filter(User.id == user.id).count()
        
        return JSONResponse(content={
            "code": 200,
            "data": {
                "user_id": user.id,
                "username": user.username,
                "image_count": image_count,
                "audit_count": audit_count,
                "join_date": user.created_at.isoformat()
            }
        })
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"获取用户统计失败: {str(e)}") 