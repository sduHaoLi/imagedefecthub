from fastapi import APIRouter, File, UploadFile, HTTPException, Depends
from fastapi.responses import JSONResponse
from typing import List, Dict, Any
import os
import uuid
from datetime import datetime
from sqlalchemy.orm import Session

from models.database import get_db, Image, DetectionResult
from utils.yolo_detector import detector
from utils.auth import get_current_user
from config import settings

router = APIRouter()

@router.post("/single")
async def detect_single_image(
    file: UploadFile = File(...),
    confidence: float = 0.5,
    nms_threshold: float = 0.4,
    db: Session = Depends(get_db)
):
    """单张图片缺陷检测"""
    try:
        # 验证文件类型
        if not file.filename.lower().endswith(tuple(settings.ALLOWED_EXTENSIONS)):
            raise HTTPException(status_code=400, detail="不支持的文件格式")
        
        # 读取文件内容
        image_data = await file.read()
        
        # 检查文件大小
        if len(image_data) > settings.MAX_FILE_SIZE:
            raise HTTPException(status_code=400, detail="文件大小超过限制")
        
        # 保存图片到本地
        filename = f"{uuid.uuid4()}_{file.filename}"
        file_path = os.path.join(settings.UPLOAD_DIR, filename)
        
        # 确保上传目录存在
        os.makedirs(settings.UPLOAD_DIR, exist_ok=True)
        
        with open(file_path, "wb") as f:
            f.write(image_data)
        
        # 使用YOLO进行检测
        defects = detector.detect_defects(image_data)
        
        # 获取统计信息
        stats = detector.get_defect_statistics(defects)
        
        # 保存到数据库（可选）
        # 这里可以添加数据库保存逻辑
        
        return JSONResponse(content={
            "code": 200,
            "message": "检测完成",
            "data": {
                "image_name": file.filename,
                "image_path": f"/uploads/{filename}",
                "defects": defects,
                "statistics": stats,
                "detect_time": datetime.now().isoformat(),
                "model_version": "YOLOv8",
                "parameters": {
                    "confidence_threshold": confidence,
                    "nms_threshold": nms_threshold
                }
            }
        })
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"检测失败: {str(e)}")

@router.post("/batch")
async def detect_batch_images(
    files: List[UploadFile] = File(...),
    confidence: float = 0.5,
    nms_threshold: float = 0.4,
    db: Session = Depends(get_db)
):
    """批量图片缺陷检测"""
    try:
        results = []
        
        for file in files:
            # 验证文件类型
            if not file.filename.lower().endswith(tuple(settings.ALLOWED_EXTENSIONS)):
                continue
            
            # 读取文件内容
            image_data = await file.read()
            
            # 检查文件大小
            if len(image_data) > settings.MAX_FILE_SIZE:
                continue
            
            # 使用YOLO进行检测
            defects = detector.detect_defects(image_data)
            
            # 获取统计信息
            stats = detector.get_defect_statistics(defects)
            
            result = {
                "image_name": file.filename,
                "defects": defects,
                "statistics": stats,
                "detect_time": datetime.now().isoformat()
            }
            
            results.append(result)
        
        return JSONResponse(content={
            "code": 200,
            "message": f"批量检测完成，共处理 {len(results)} 张图片",
            "data": {
                "results": results,
                "total_images": len(results),
                "parameters": {
                    "confidence_threshold": confidence,
                    "nms_threshold": nms_threshold
                }
            }
        })
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"批量检测失败: {str(e)}")

@router.get("/config")
async def get_detection_config():
    """获取检测配置"""
    return JSONResponse(content={
        "code": 200,
        "data": {
            "confidence_threshold": settings.CONFIDENCE_THRESHOLD,
            "nms_threshold": settings.NMS_THRESHOLD,
            "model_path": settings.MODEL_PATH,
            "allowed_extensions": list(settings.ALLOWED_EXTENSIONS),
            "max_file_size": settings.MAX_FILE_SIZE
        }
    })

@router.post("/config")
async def update_detection_config(
    confidence_threshold: float = 0.5,
    nms_threshold: float = 0.4
):
    """更新检测配置"""
    try:
        # 更新检测器配置
        detector.confidence_threshold = confidence_threshold
        detector.nms_threshold = nms_threshold
        
        return JSONResponse(content={
            "code": 200,
            "message": "配置更新成功",
            "data": {
                "confidence_threshold": confidence_threshold,
                "nms_threshold": nms_threshold
            }
        })
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"配置更新失败: {str(e)}")

@router.get("/model-info")
async def get_model_info():
    """获取模型信息"""
    try:
        model_info = {
            "model_path": settings.MODEL_PATH,
            "model_exists": os.path.exists(settings.MODEL_PATH),
            "confidence_threshold": detector.confidence_threshold,
            "nms_threshold": detector.nms_threshold,
            "model_loaded": detector.model is not None
        }
        
        return JSONResponse(content={
            "code": 200,
            "data": model_info
        })
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"获取模型信息失败: {str(e)}") 