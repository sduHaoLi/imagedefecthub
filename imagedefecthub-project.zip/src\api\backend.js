import request from './request'

// 缺陷检测API
export function detectDefects(file, confidence = 0.5, nmsThreshold = 0.4) {
  const formData = new FormData()
  formData.append('file', file)
  formData.append('confidence', confidence)
  formData.append('nms_threshold', nmsThreshold)
  
  return request({
    url: '/detect/single',
    method: 'post',
    data: formData,
    headers: { 'Content-Type': 'multipart/form-data' }
  })
}

export function detectBatchDefects(files, confidence = 0.5, nmsThreshold = 0.4) {
  const formData = new FormData()
  files.forEach(file => {
    formData.append('files', file)
  })
  formData.append('confidence', confidence)
  formData.append('nms_threshold', nmsThreshold)
  
  return request({
    url: '/detect/batch',
    method: 'post',
    data: formData,
    headers: { 'Content-Type': 'multipart/form-data' }
  })
}

export function getDetectionConfig() {
  return request({
    url: '/detect/config',
    method: 'get'
  })
}

export function updateDetectionConfig(confidence, nmsThreshold) {
  return request({
    url: '/detect/config',
    method: 'post',
    data: { confidence_threshold: confidence, nms_threshold: nmsThreshold }
  })
}

// 图像管理API
export function uploadImage(file) {
  const formData = new FormData()
  formData.append('file', file)
  
  return request({
    url: '/images/upload',
    method: 'post',
    data: formData,
    headers: { 'Content-Type': 'multipart/form-data' }
  })
}

export function getImageList(page = 1, pageSize = 20, search = '', sortBy = 'uploaded_at', sortOrder = 'desc') {
  return request({
    url: '/images/list',
    method: 'get',
    params: { page, page_size: pageSize, search, sort_by: sortBy, sort_order: sortOrder }
  })
}

export function deleteImage(imageId) {
  return request({
    url: `/images/${imageId}`,
    method: 'delete'
  })
}

export function deleteBatchImages(imageIds) {
  return request({
    url: '/images/batch',
    method: 'delete',
    data: { image_ids: imageIds }
  })
}

// 缺陷审核API
export function getAuditList(page = 1, pageSize = 20, status = '', defectType = '', startDate = '', endDate = '', search = '') {
  return request({
    url: '/audit/list',
    method: 'get',
    params: { page, page_size: pageSize, status, defect_type: defectType, start_date: startDate, end_date: endDate, search }
  })
}

export function updateAuditStatus(auditId, auditStatus, notes = '') {
  return request({
    url: `/audit/${auditId}`,
    method: 'post',
    data: { audit_status: auditStatus, notes }
  })
}

export function batchAudit(auditIds, auditStatus, notes = '') {
  return request({
    url: '/audit/batch',
    method: 'post',
    data: { audit_records: auditIds, audit_status: auditStatus, notes }
  })
}

// 报告生成API
export function generateReport(reportType, imageIds = [], defectTypes = [], startDate = '', endDate = '', format = 'pdf') {
  return request({
    url: '/reports/generate',
    method: 'post',
    data: {
      report_type: reportType,
      image_ids: imageIds,
      defect_types: defectTypes,
      start_date: startDate,
      end_date: endDate,
      format
    }
  })
}

export function downloadReport(reportId) {
  return request({
    url: `/reports/download/${reportId}`,
    method: 'get',
    responseType: 'blob'
  })
}

export function getReportHistory(page = 1, pageSize = 20) {
  return request({
    url: '/reports/history',
    method: 'get',
    params: { page, page_size: pageSize }
  })
}

// 用户管理API
export function getUserInfo() {
  return request({
    url: '/user/info',
    method: 'get'
  })
}

export function updateUserInfo(fullName, email) {
  return request({
    url: '/user/update',
    method: 'put',
    data: { full_name: fullName, email }
  })
}

export function changePassword(oldPassword, newPassword) {
  return request({
    url: '/user/change-password',
    method: 'post',
    data: { old_password: oldPassword, new_password: newPassword }
  })
}

export function uploadAvatar(file) {
  const formData = new FormData()
  formData.append('file', file)
  
  return request({
    url: '/user/upload-avatar',
    method: 'post',
    data: formData,
    headers: { 'Content-Type': 'multipart/form-data' }
  })
}

// 认证API
export function login(username, password) {
  return request({
    url: '/auth/login',
    method: 'post',
    data: { username, password }
  })
}

export function register(username, email, password, fullName = '') {
  return request({
    url: '/auth/register',
    method: 'post',
    data: { username, email, password, full_name: fullName }
  })
}

export function logout() {
  return request({
    url: '/auth/logout',
    method: 'post'
  })
}

export function verifyToken(token) {
  return request({
    url: '/auth/verify',
    method: 'get',
    params: { token }
  })
}

// 统计API
export function getImageStatistics() {
  return request({
    url: '/images/statistics',
    method: 'get'
  })
}

export function getAuditStatistics() {
  return request({
    url: '/audit/statistics',
    method: 'get'
  })
}

export function getPendingAuditCount() {
  return request({
    url: '/audit/pending-count',
    method: 'get'
  })
}

export function getUserStatistics() {
  return request({
    url: '/user/statistics',
    method: 'get'
  })
}

// 模型信息API
export function getModelInfo() {
  return request({
    url: '/detect/model-info',
    method: 'get'
  })
} 