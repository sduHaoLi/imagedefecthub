<template>
  <div class="page-container">
    <!-- 页面标题 -->
    <div class="dashboard-header">
      <h2>缺陷检测统计总览</h2>
      <p class="subtitle">实时监控图像缺陷检测系统的运行状态和关键指标</p>
    </div>

    <!-- 统计卡片 -->
    <el-row :gutter="20" class="stats-row">
      <el-col :span="6">
        <el-card class="stat-card" shadow="hover">
          <div class="stat-content">
            <div class="stat-icon">
              <el-icon><Picture /></el-icon>
            </div>
            <div class="stat-info">
              <div class="stat-number">{{ stats.totalImages }}</div>
              <div class="stat-label">检测图片总数</div>
              <div class="stat-trend">
                <span class="trend-up">+12.5%</span>
                <span class="trend-text">较昨日</span>
              </div>
            </div>
          </div>
        </el-card>
      </el-col>
      
      <el-col :span="6">
        <el-card class="stat-card" shadow="hover">
          <div class="stat-content">
            <div class="stat-icon defect">
              <el-icon><Warning /></el-icon>
            </div>
            <div class="stat-info">
              <div class="stat-number">{{ stats.totalDefects }}</div>
              <div class="stat-label">发现缺陷总数</div>
              <div class="stat-trend">
                <span class="trend-down">-5.2%</span>
                <span class="trend-text">较昨日</span>
              </div>
            </div>
          </div>
        </el-card>
      </el-col>
      
      <el-col :span="6">
        <el-card class="stat-card" shadow="hover">
          <div class="stat-content">
            <div class="stat-icon success">
              <el-icon><Check /></el-icon>
            </div>
            <div class="stat-info">
              <div class="stat-number">{{ stats.auditRate }}%</div>
              <div class="stat-label">审核通过率</div>
              <div class="stat-trend">
                <span class="trend-up">+2.1%</span>
                <span class="trend-text">较昨日</span>
              </div>
            </div>
          </div>
        </el-card>
      </el-col>
      
      <el-col :span="6">
        <el-card class="stat-card" shadow="hover">
          <div class="stat-content">
            <div class="stat-icon warning">
              <el-icon><Clock /></el-icon>
            </div>
            <div class="stat-info">
              <div class="stat-number">{{ stats.avgProcessTime }}s</div>
              <div class="stat-label">平均处理时间</div>
              <div class="stat-trend">
                <span class="trend-down">-8.3%</span>
                <span class="trend-text">较昨日</span>
              </div>
            </div>
          </div>
        </el-card>
      </el-col>
    </el-row>

    <!-- 图表和活动区域 -->
    <el-row :gutter="20" class="charts-row">
      <!-- 左侧图表 -->
      <el-col :span="16">
        <el-card class="chart-card" shadow="hover">
          <template #header>
            <div class="card-header">
              <span>缺陷类型分布</span>
              <el-radio-group v-model="chartTimeRange" size="small">
                <el-radio-button label="week">本周</el-radio-button>
                <el-radio-button label="month">本月</el-radio-button>
                <el-radio-button label="year">本年</el-radio-button>
              </el-radio-group>
            </div>
          </template>
          <div class="chart-container">
            <div class="chart-placeholder">
              <el-icon class="chart-icon"><PieChart /></el-icon>
              <p>缺陷类型分布饼图</p>
              <p class="chart-desc">显示各类缺陷的占比情况</p>
            </div>
          </div>
        </el-card>
      </el-col>
      
      <!-- 右侧活动 -->
      <el-col :span="8">
        <el-card class="activity-card" shadow="hover">
          <template #header>
            <span>最近活动</span>
          </template>
          <div class="activity-list">
            <div v-for="activity in recentActivities" :key="activity.id" class="activity-item">
              <div class="activity-icon" :class="activity.type">
                <el-icon><component :is="activity.icon" /></el-icon>
              </div>
              <div class="activity-content">
                <div class="activity-title">{{ activity.title }}</div>
                <div class="activity-time">{{ activity.time }}</div>
              </div>
            </div>
          </div>
        </el-card>
      </el-col>
    </el-row>

    <!-- 快速操作和系统状态 -->
    <el-row :gutter="20" class="bottom-row">
      <!-- 快速操作 -->
      <el-col :span="12">
        <el-card class="quick-actions-card" shadow="hover">
          <template #header>
            <span>快速操作</span>
          </template>
          <!-- 快速操作区按钮内容彻底对齐 -->
          <div class="quick-actions">
            <el-button type="primary" size="large" @click="goToImageUpload">
              <el-icon><Upload /></el-icon>
              <span>上传图片</span>
            </el-button>
            <el-button type="success" size="large" @click="goToDefectDetect">
              <el-icon><Search /></el-icon>
              <span>开始检测</span>
            </el-button>
            <el-button type="warning" size="large" @click="goToDefectAudit">
              <el-icon><Check /></el-icon>
              <span>缺陷审核</span>
            </el-button>
            <el-button type="info" size="large" @click="goToReportCenter">
              <el-icon><Document /></el-icon>
              <span>生成报告</span>
            </el-button>
          </div>
        </el-card>
      </el-col>
      
      <!-- 系统状态 -->
      <el-col :span="12">
        <el-card class="system-status-card" shadow="hover">
          <template #header>
            <span>系统状态</span>
          </template>
          <div class="system-status">
            <div class="status-item">
              <div class="status-label">AI模型状态</div>
              <div class="status-value">
                <el-tag type="success" size="small">运行中</el-tag>
              </div>
            </div>
            <div class="status-item">
              <div class="status-label">数据库连接</div>
              <div class="status-value">
                <el-tag type="success" size="small">正常</el-tag>
              </div>
            </div>
            <div class="status-item">
              <div class="status-label">存储空间</div>
              <div class="status-value">
                <el-tag type="warning" size="small">75%</el-tag>
              </div>
            </div>
            <div class="status-item">
              <div class="status-label">系统负载</div>
              <div class="status-value">
                <el-tag type="success" size="small">正常</el-tag>
              </div>
            </div>
          </div>
        </el-card>
      </el-col>
    </el-row>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { 
  Picture, Warning, Check, Clock, PieChart, Upload, 
  Search, Document, View, Delete, Download 
} from '@element-plus/icons-vue'

const router = useRouter()

// 图表时间范围
const chartTimeRange = ref('week')

// 统计数据
const stats = reactive({
  totalImages: 1250,
  totalDefects: 89,
  auditRate: 94.5,
  avgProcessTime: 2.3
})

// 最近活动
const recentActivities = ref([
  {
    id: 1,
    icon: 'Upload',
    title: '上传了15张检测图片',
    time: '2分钟前',
    type: 'upload'
  },
  {
    id: 2,
    icon: 'Search',
    title: '完成了缺陷检测任务',
    time: '5分钟前',
    type: 'detect'
  },
  {
    id: 3,
    icon: 'Check',
    title: '审核通过了8张图片',
    time: '12分钟前',
    type: 'audit'
  },
  {
    id: 4,
    icon: 'View',
    title: '查看了检测报告',
    time: '25分钟前',
    type: 'view'
  },
  {
    id: 5,
    icon: 'Delete',
    title: '删除了3张无效图片',
    time: '1小时前',
    type: 'delete'
  }
])

// 页面跳转方法
const goToImageUpload = () => {
  router.push('/image-manage')
}

const goToDefectDetect = () => {
  router.push('/defect-detect')
}

const goToDefectAudit = () => {
  router.push('/defect-audit')
}

const goToReportCenter = () => {
  router.push('/report-center')
}

// 页面加载时获取数据
onMounted(() => {
  // 这里可以调用API获取实时数据
  console.log('Dashboard页面加载完成')
})
</script>

<style lang="scss" scoped>
.dashboard-header {
  margin-bottom: 24px;
  
  .subtitle {
    color: #666;
    margin-top: 8px;
    font-size: 14px;
  }
}

.stats-row {
  margin-bottom: 20px;
}

.stat-card {
  .stat-content {
    display: flex;
    align-items: center;
    
    .stat-icon {
      width: 60px;
      height: 60px;
      border-radius: 12px;
      display: flex;
      align-items: center;
      justify-content: center;
      margin-right: 16px;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      
      &.defect {
        background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
      }
      
      &.success {
        background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
      }
      
      &.warning {
        background: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%);
      }
      
      .el-icon {
        font-size: 24px;
        color: white;
      }
    }
    
    .stat-info {
      flex: 1;
      
      .stat-number {
        font-size: 28px;
        font-weight: bold;
        color: #303133;
        margin-bottom: 4px;
      }
      
      .stat-label {
        font-size: 14px;
        color: #606266;
        margin-bottom: 8px;
      }
      
      .stat-trend {
        font-size: 12px;
        
        .trend-up {
          color: #67c23a;
          font-weight: 500;
        }
        
        .trend-down {
          color: #f56c6c;
          font-weight: 500;
        }
        
        .trend-text {
          color: #909399;
          margin-left: 4px;
        }
      }
    }
  }
}

.charts-row {
  margin-bottom: 20px;
}

.chart-card {
  .card-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
  }
  
  .chart-container {
    height: 320px;
    
    .chart-placeholder {
      height: 100%;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      color: #909399;
      
      .chart-icon {
        font-size: 48px;
        margin-bottom: 16px;
        color: #c0c4cc;
      }
      
      .chart-desc {
        font-size: 12px;
        margin-top: 8px;
        color: #c0c4cc;
      }
    }
  }
}

.activity-card {
  .activity-list {
    .activity-item {
      display: flex;
      align-items: center;
      padding: 12px 0;
      border-bottom: 1px solid #f0f0f0;
      
      &:last-child {
        border-bottom: none;
      }
      
      .activity-icon {
        width: 32px;
        height: 32px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        margin-right: 12px;
        
        &.upload {
          background: #409eff;
        }
        
        &.detect {
          background: #67c23a;
        }
        
        &.audit {
          background: #e6a23c;
        }
        
        &.view {
          background: #909399;
        }
        
        &.delete {
          background: #f56c6c;
        }
        
        .el-icon {
          color: white;
          font-size: 16px;
        }
      }
      
      .activity-content {
        flex: 1;
        
        .activity-title {
          font-size: 14px;
          color: #303133;
          margin-bottom: 4px;
        }
        
        .activity-time {
          font-size: 12px;
          color: #909399;
        }
      }
    }
  }
}

.bottom-row {
  .quick-actions-card {
    .quick-actions {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 16px;
      
      .el-button {
        height: 60px;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        
        .btn-content {
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
        }
        .el-icon {
          font-size: 28px;
          margin-bottom: 6px;
        }
        span {
          font-size: 16px;
        }
      }
    }
  }
  
  .system-status-card {
    .system-status {
      .status-item {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 12px 0;
        border-bottom: 1px solid #f0f0f0;
        
        &:last-child {
          border-bottom: none;
        }
        
        .status-label {
          font-size: 14px;
          color: #606266;
        }
        
        .status-value {
          .el-tag {
            min-width: 60px;
            text-align: center;
          }
        }
      }
    }
  }
}

// 响应式设计
@media (max-width: 768px) {
  .stats-row {
    .el-col {
      margin-bottom: 16px;
    }
  }
  
  .charts-row {
    .el-col {
      margin-bottom: 16px;
    }
  }
  
  .bottom-row {
    .el-col {
      margin-bottom: 16px;
    }
  }
  
  .quick-actions {
    grid-template-columns: 1fr !important;
  }
}

.quick-actions .el-button {
  display: flex !important;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  height: 80px;
  padding: 0;
  text-align: center;
}
.quick-actions .el-button .el-icon {
  font-size: 32px;
  margin-bottom: 8px;
  display: block;
  width: 100%;
  text-align: center;
  line-height: 1;
}
.quick-actions .el-button span {
  font-size: 18px;
  display: block;
  width: 100%;
  text-align: center;
  line-height: 1;
}
</style> 