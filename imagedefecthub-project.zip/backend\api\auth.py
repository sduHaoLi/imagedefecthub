from fastapi import APIRouter, HTTPException, Depends
from fastapi.responses import JSONResponse
from pydantic import BaseModel
from datetime import timedelta
from sqlalchemy.orm import Session

from models.database import get_db, User
from utils.auth import verify_password, get_password_hash, create_access_token
from config import settings

router = APIRouter()

class LoginRequest(BaseModel):
    username: str
    password: str

class RegisterRequest(BaseModel):
    username: str
    email: str
    password: str
    full_name: str = None

@router.post("/login")
async def login(
    login_data: LoginRequest,
    db: Session = Depends(get_db)
):
    """用户登录"""
    try:
        # 查找用户
        user = db.query(User).filter(User.username == login_data.username).first()
        
        if not user or not verify_password(login_data.password, user.hashed_password):
            raise HTTPException(status_code=401, detail="用户名或密码错误")
        
        if not user.is_active:
            raise HTTPException(status_code=401, detail="账户已被禁用")
        
        # 创建访问令牌
        access_token = create_access_token(
            data={"sub": user.username},
            expires_delta=timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES)
        )
        
        return JSONResponse(content={
            "code": 200,
            "message": "登录成功",
            "data": {
                "access_token": access_token,
                "token_type": "bearer",
                "user_info": {
                    "id": user.id,
                    "username": user.username,
                    "email": user.email,
                    "full_name": user.full_name,
                    "avatar_url": user.avatar_url
                }
            }
        })
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"登录失败: {str(e)}")

@router.post("/register")
async def register(
    register_data: RegisterRequest,
    db: Session = Depends(get_db)
):
    """用户注册"""
    try:
        # 检查用户名是否已存在
        existing_user = db.query(User).filter(User.username == register_data.username).first()
        if existing_user:
            raise HTTPException(status_code=400, detail="用户名已存在")
        
        # 检查邮箱是否已存在
        existing_email = db.query(User).filter(User.email == register_data.email).first()
        if existing_email:
            raise HTTPException(status_code=400, detail="邮箱已存在")
        
        # 创建新用户
        hashed_password = get_password_hash(register_data.password)
        new_user = User(
            username=register_data.username,
            email=register_data.email,
            hashed_password=hashed_password,
            full_name=register_data.full_name
        )
        
        db.add(new_user)
        db.commit()
        db.refresh(new_user)
        
        return JSONResponse(content={
            "code": 200,
            "message": "注册成功",
            "data": {
                "id": new_user.id,
                "username": new_user.username,
                "email": new_user.email,
                "full_name": new_user.full_name
            }
        })
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"注册失败: {str(e)}")

@router.post("/logout")
async def logout():
    """用户登出"""
    return JSONResponse(content={
        "code": 200,
        "message": "登出成功"
    })

@router.get("/verify")
async def verify_token(token: str):
    """验证令牌"""
    try:
        from utils.auth import verify_token as verify_jwt_token
        
        payload = verify_jwt_token(token)
        if payload is None:
            raise HTTPException(status_code=401, detail="无效的令牌")
        
        return JSONResponse(content={
            "code": 200,
            "message": "令牌有效",
            "data": payload
        })
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"令牌验证失败: {str(e)}") 