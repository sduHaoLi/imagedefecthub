<template>
  <div class="page-container">
    <!-- 页面标题 -->
    <div class="page-header">
      <h2>报告中心</h2>
      <p class="subtitle">生成和导出各类检测报告，支持多种格式和自定义配置</p>
    </div>

    <el-row :gutter="20">
      <!-- 左侧：报告配置 -->
      <el-col :span="8">
        <!-- 报告类型选择 -->
        <el-card class="config-card" shadow="hover">
          <template #header>
            <span>报告类型</span>
          </template>
          
          <el-radio-group v-model="reportConfig.type" class="report-type-group">
            <el-radio-button value="daily">日报</el-radio-button>
            <el-radio-button value="weekly">周报</el-radio-button>
            <el-radio-button value="monthly">月报</el-radio-button>
            <el-radio-button value="custom">自定义</el-radio-button>
          </el-radio-group>
          
          <div class="type-description">
            <p v-if="reportConfig.type === 'daily'">每日检测数据汇总，包含检测数量、缺陷统计等</p>
            <p v-else-if="reportConfig.type === 'weekly'">本周检测数据汇总，包含趋势分析和对比</p>
            <p v-else-if="reportConfig.type === 'monthly'">本月检测数据汇总，包含详细统计和图表</p>
            <p v-else-if="reportConfig.type === 'custom'">自定义时间范围和内容的报告</p>
          </div>
        </el-card>

        <!-- 时间范围配置 -->
        <el-card class="config-card" shadow="hover" style="margin-top: 20px;">
          <template #header>
            <span>时间范围</span>
          </template>
          
          <el-form :model="reportConfig" label-width="80px">
            <el-form-item label="开始日期">
              <el-date-picker
                v-model="reportConfig.startDate"
                type="date"
                placeholder="选择开始日期"
                style="width: 100%"
              />
            </el-form-item>
            
            <el-form-item label="结束日期">
              <el-date-picker
                v-model="reportConfig.endDate"
                type="date"
                placeholder="选择结束日期"
                style="width: 100%"
              />
            </el-form-item>
            
            <el-form-item label="快速选择">
              <el-select v-model="quickDateRange" placeholder="快速选择时间范围" style="width: 100%" @change="handleQuickDateChange">
                <el-option label="今天" value="today" />
                <el-option label="昨天" value="yesterday" />
                <el-option label="最近7天" value="last7days" />
                <el-option label="最近30天" value="last30days" />
                <el-option label="本月" value="thisMonth" />
                <el-option label="上月" value="lastMonth" />
              </el-select>
            </el-form-item>
          </el-form>
        </el-card>

        <!-- 报告内容配置 -->
        <el-card class="config-card" shadow="hover" style="margin-top: 20px;">
          <template #header>
            <span>报告内容</span>
          </template>
          
          <el-form :model="reportConfig" label-width="80px">
            <el-form-item label="包含内容">
              <el-checkbox-group v-model="reportConfig.includeContent">
                <el-checkbox label="summary">数据汇总</el-checkbox>
                <el-checkbox label="defectStats">缺陷统计</el-checkbox>
                <el-checkbox label="trendAnalysis">趋势分析</el-checkbox>
                <el-checkbox label="qualityMetrics">质量指标</el-checkbox>
                <el-checkbox label="defectDetails">缺陷详情</el-checkbox>
                <el-checkbox label="charts">图表展示</el-checkbox>
              </el-checkbox-group>
            </el-form-item>
            
            <el-form-item label="缺陷类型">
              <el-checkbox-group v-model="reportConfig.defectTypes">
                <el-checkbox label="crack">裂纹</el-checkbox>
                <el-checkbox label="scratch">划痕</el-checkbox>
                <el-checkbox label="stain">污渍</el-checkbox>
                <el-checkbox label="dent">凹陷</el-checkbox>
                <el-checkbox label="color">色差</el-checkbox>
              </el-checkbox-group>
            </el-form-item>
            
            <el-form-item label="排序方式">
              <el-select v-model="reportConfig.sortBy" placeholder="选择排序方式" style="width: 100%">
                <el-option label="按时间排序" value="time" />
                <el-option label="按缺陷数量排序" value="defectCount" />
                <el-option label="按严重程度排序" value="severity" />
              </el-select>
            </el-form-item>
          </el-form>
        </el-card>

        <!-- 导出格式配置 -->
        <el-card class="config-card" shadow="hover" style="margin-top: 20px;">
          <template #header>
            <span>导出格式</span>
          </template>
          
          <el-form :model="reportConfig" label-width="80px">
            <el-form-item label="文件格式">
              <el-radio-group v-model="reportConfig.format">
                <el-radio label="pdf">PDF</el-radio>
                <el-radio label="excel">Excel</el-radio>
                <el-radio label="word">Word</el-radio>
                <el-radio label="html">HTML</el-radio>
              </el-radio-group>
            </el-form-item>
            
            <el-form-item label="模板选择">
              <el-select v-model="reportConfig.template" placeholder="选择报告模板" style="width: 100%">
                <el-option label="标准模板" value="standard" />
                <el-option label="详细模板" value="detailed" />
                <el-option label="简洁模板" value="simple" />
                <el-option label="自定义模板" value="custom" />
              </el-select>
            </el-form-item>
            
            <el-form-item label="报告标题">
              <el-input v-model="reportConfig.title" placeholder="输入报告标题" />
            </el-form-item>
            
            <el-form-item label="备注">
              <el-input
                v-model="reportConfig.notes"
                type="textarea"
                :rows="3"
                placeholder="添加报告备注..."
              />
            </el-form-item>
          </el-form>
        </el-card>
      </el-col>

      <!-- 右侧：预览和操作 -->
      <el-col :span="16">
        <!-- 报告预览 -->
        <el-card class="preview-card" shadow="hover">
          <template #header>
            <div class="preview-header">
              <span>报告预览</span>
              <div class="preview-actions">
                <el-button size="small" @click="refreshPreview">
                  <el-icon><Refresh /></el-icon>
                  刷新预览
                </el-button>
                <el-button size="small" @click="generateReport" :loading="generating">
                  <el-icon><Document /></el-icon>
                  生成报告
                </el-button>
              </div>
            </div>
          </template>
          
          <!-- 预览内容 -->
          <div class="preview-content">
            <div v-if="previewData" class="report-preview">
              <div class="report-header">
                <h3>{{ previewData.title }}</h3>
                <p class="report-subtitle">{{ previewData.subtitle }}</p>
              </div>
              
              <div class="report-summary">
                <el-row :gutter="20">
                  <el-col :span="6">
                    <div class="summary-item">
                      <div class="summary-number">{{ previewData.totalImages }}</div>
                      <div class="summary-label">检测图片</div>
                    </div>
                  </el-col>
                  <el-col :span="6">
                    <div class="summary-item">
                      <div class="summary-number">{{ previewData.totalDefects }}</div>
                      <div class="summary-label">发现缺陷</div>
                    </div>
                  </el-col>
                  <el-col :span="6">
                    <div class="summary-item">
                      <div class="summary-number">{{ previewData.defectRate }}%</div>
                      <div class="summary-label">缺陷率</div>
                    </div>
                  </el-col>
                  <el-col :span="6">
                    <div class="summary-item">
                      <div class="summary-number">{{ previewData.avgProcessTime }}s</div>
                      <div class="summary-label">平均处理时间</div>
                    </div>
                  </el-col>
                </el-row>
              </div>
              
              <div class="report-charts">
                <div class="chart-placeholder">
                  <el-icon class="chart-icon"><PieChart /></el-icon>
                  <p>缺陷类型分布图</p>
                </div>
                <div class="chart-placeholder">
                  <el-icon class="chart-icon"><TrendCharts /></el-icon>
                  <p>检测趋势图</p>
                </div>
              </div>
              
              <div class="report-details">
                <h4>缺陷详情</h4>
                <el-table :data="previewData.defectDetails" style="width: 100%">
                  <el-table-column prop="type" label="缺陷类型" width="120" />
                  <el-table-column prop="count" label="数量" width="80" />
                  <el-table-column prop="percentage" label="占比" width="80" />
                  <el-table-column prop="severity" label="严重程度" width="100" />
                  <el-table-column prop="trend" label="趋势" />
                </el-table>
              </div>
              <!-- 新增：回到仪表板和查看图片管理按钮 -->
              <div class="go-next-wrapper">
                <el-button type="primary" size="large" @click="goToDashboard">
                  <el-icon><PieChart /></el-icon>
                  回到仪表板
                </el-button>
                <el-button type="info" size="large" @click="goToImageManage">
                  <el-icon><Picture /></el-icon>
                  查看图片管理
                </el-button>
              </div>
            </div>
            
            <!-- 空状态 -->
            <div v-else class="empty-preview">
              <el-empty description="暂无预览数据">
                <template #image>
                  <el-icon style="font-size: 60px; color: #c0c4cc;"><Document /></el-icon>
                </template>
                <template #description>
                  <p>请配置报告参数并点击"生成报告"</p>
                </template>
              </el-empty>
            </div>
          </div>
        </el-card>

        <!-- 历史报告 -->
        <el-card class="history-card" shadow="hover" style="margin-top: 20px;">
          <template #header>
            <span>历史报告</span>
          </template>
          
          <el-table :data="historyReports" style="width: 100%">
            <el-table-column prop="title" label="报告标题" min-width="200" />
            <el-table-column prop="type" label="类型" width="80">
              <template #default="{ row }">
                <el-tag :type="getReportTypeTag(row.type)" size="small">
                  {{ getReportTypeText(row.type) }}
                </el-tag>
              </template>
            </el-table-column>
            <el-table-column prop="format" label="格式" width="80" />
            <el-table-column prop="createTime" label="生成时间" width="180" />
            <el-table-column prop="size" label="文件大小" width="100" />
            <el-table-column label="操作" width="150" fixed="right">
              <template #default="{ row }">
                <el-button size="small" @click="downloadReport(row)">
                  <el-icon><Download /></el-icon>
                  下载
                </el-button>
                <el-button size="small" type="danger" @click="deleteReport(row)">
                  <el-icon><Delete /></el-icon>
                  删除
                </el-button>
              </template>
            </el-table-column>
          </el-table>
        </el-card>
      </el-col>
    </el-row>
  </div>
</template>

<script setup>
import { ref, reactive, computed, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { ElMessage, ElMessageBox } from 'element-plus'
import { Refresh, Document, Download, Delete, PieChart, TrendCharts, Picture } from '@element-plus/icons-vue'

// 报告配置
const reportConfig = reactive({
  type: 'daily',
  startDate: null,
  endDate: null,
  includeContent: ['summary', 'defectStats', 'trendAnalysis'],
  defectTypes: ['crack', 'scratch', 'stain', 'dent', 'color'],
  sortBy: 'time',
  format: 'pdf',
  template: 'standard',
  title: '',
  notes: ''
})

// 快速日期选择
const quickDateRange = ref('')

// 生成状态
const generating = ref(false)

// 预览数据
const previewData = ref(null)

// 历史报告
const historyReports = ref([
  {
    id: 1,
    title: '2024年1月15日检测日报',
    type: 'daily',
    format: 'PDF',
    createTime: '2024-01-15 18:00:00',
    size: '2.5MB'
  },
  {
    id: 2,
    title: '2024年第2周检测周报',
    type: 'weekly',
    format: 'Excel',
    createTime: '2024-01-14 17:30:00',
    size: '1.8MB'
  },
  {
    id: 3,
    title: '2023年12月检测月报',
    type: 'monthly',
    format: 'PDF',
    createTime: '2024-01-01 09:00:00',
    size: '5.2MB'
  }
])

// 工具方法
const getReportTypeTag = (type) => {
  const tagMap = {
    daily: 'primary',
    weekly: 'success',
    monthly: 'warning',
    custom: 'info'
  }
  return tagMap[type] || 'info'
}

const getReportTypeText = (type) => {
  const textMap = {
    daily: '日报',
    weekly: '周报',
    monthly: '月报',
    custom: '自定义'
  }
  return textMap[type] || '未知'
}

// 快速日期选择处理
const handleQuickDateChange = (value) => {
  const now = new Date()
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate())
  
  switch (value) {
    case 'today':
      reportConfig.startDate = today
      reportConfig.endDate = today
      break
    case 'yesterday':
      const yesterday = new Date(today)
      yesterday.setDate(yesterday.getDate() - 1)
      reportConfig.startDate = yesterday
      reportConfig.endDate = yesterday
      break
    case 'last7days':
      const last7days = new Date(today)
      last7days.setDate(last7days.getDate() - 7)
      reportConfig.startDate = last7days
      reportConfig.endDate = today
      break
    case 'last30days':
      const last30days = new Date(today)
      last30days.setDate(last30days.getDate() - 30)
      reportConfig.startDate = last30days
      reportConfig.endDate = today
      break
    case 'thisMonth':
      const thisMonth = new Date(now.getFullYear(), now.getMonth(), 1)
      reportConfig.startDate = thisMonth
      reportConfig.endDate = today
      break
    case 'lastMonth':
      const lastMonth = new Date(now.getFullYear(), now.getMonth() - 1, 1)
      const lastMonthEnd = new Date(now.getFullYear(), now.getMonth(), 0)
      reportConfig.startDate = lastMonth
      reportConfig.endDate = lastMonthEnd
      break
  }
  
  quickDateRange.value = ''
}

// 生成预览数据
const generatePreviewData = () => {
  const typeTextMap = {
    daily: '日报',
    weekly: '周报',
    monthly: '月报',
    custom: '自定义报告'
  }
  
  previewData.value = {
    title: reportConfig.title || `${formatDate(reportConfig.startDate)} ${typeTextMap[reportConfig.type]}`,
    subtitle: `报告时间：${formatDate(reportConfig.startDate)} 至 ${formatDate(reportConfig.endDate)}`,
    totalImages: 1250,
    totalDefects: 89,
    defectRate: 7.1,
    avgProcessTime: 2.3,
    defectDetails: [
      { type: '裂纹', count: 25, percentage: '28.1%', severity: '高', trend: '下降' },
      { type: '划痕', count: 18, percentage: '20.2%', severity: '中', trend: '稳定' },
      { type: '污渍', count: 15, percentage: '16.9%', severity: '低', trend: '上升' },
      { type: '凹陷', count: 12, percentage: '13.5%', severity: '中', trend: '下降' },
      { type: '色差', count: 19, percentage: '21.3%', severity: '低', trend: '稳定' }
    ]
  }
}

const formatDate = (date) => {
  if (!date) return ''
  return new Date(date).toLocaleDateString('zh-CN')
}

// 操作方法
const refreshPreview = () => {
  if (reportConfig.startDate && reportConfig.endDate) {
    generatePreviewData()
    ElMessage.success('预览已刷新')
  } else {
    ElMessage.warning('请先选择时间范围')
  }
}

const generateReport = async () => {
  if (!reportConfig.startDate || !reportConfig.endDate) {
    ElMessage.warning('请选择时间范围')
    return
  }
  
  if (reportConfig.includeContent.length === 0) {
    ElMessage.warning('请选择报告内容')
    return
  }
  
  generating.value = true
  
  try {
    // 模拟生成过程
    await new Promise(resolve => setTimeout(resolve, 2000))
    
    // 生成预览数据
    generatePreviewData()
    
    // 添加到历史记录
    const newReport = {
      id: Date.now(),
      title: previewData.value.title,
      type: reportConfig.type,
      format: reportConfig.format.toUpperCase(),
      createTime: new Date().toLocaleString('zh-CN'),
      size: `${(Math.random() * 5 + 1).toFixed(1)}MB`
    }
    
    historyReports.value.unshift(newReport)
    
    ElMessage.success('报告生成成功')
  } catch (error) {
    ElMessage.error('报告生成失败')
  } finally {
    generating.value = false
  }
}

const downloadReport = (report) => {
  ElMessage.success(`开始下载 ${report.title}`)
}

const deleteReport = async (report) => {
  try {
    await ElMessageBox.confirm(`确定删除报告"${report.title}"吗？`, '确认删除', {
      confirmButtonText: '确定',
      cancelButtonText: '取消',
      type: 'warning'
    })
    
    const index = historyReports.value.findIndex(r => r.id === report.id)
    if (index > -1) {
      historyReports.value.splice(index, 1)
      ElMessage.success('删除成功')
    }
  } catch {
    // 用户取消
  }
}

const router = useRouter()

const goToDashboard = () => {
  router.push('/dashboard')
}
const goToImageManage = () => {
  router.push('/image-manage')
}

onMounted(() => {
  // 设置默认时间范围（今天）
  const today = new Date()
  reportConfig.startDate = today
  reportConfig.endDate = today
  
  // 生成默认预览
  generatePreviewData()
  
  console.log('报告中心页面加载完成')
})
</script>

<style lang="scss" scoped>
.page-header {
  margin-bottom: 24px;
  
  .subtitle {
    color: #666;
    margin-top: 8px;
    font-size: 14px;
  }
}

.config-card {
  .report-type-group {
    width: 100%;
    margin-bottom: 16px;
    
    .el-radio-button {
      width: 25%;
    }
  }
  
  .type-description {
    p {
      color: #606266;
      font-size: 14px;
      margin: 0;
      line-height: 1.5;
    }
  }
  
  .el-form-item {
    margin-bottom: 20px;
  }
}

.preview-card {
  .preview-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    
    .preview-actions {
      display: flex;
      gap: 8px;
    }
  }
  
  .preview-content {
    min-height: 400px;
    
    .report-preview {
      .report-header {
        text-align: center;
        margin-bottom: 24px;
        
        h3 {
          margin: 0 0 8px 0;
          color: #303133;
        }
        
        .report-subtitle {
          color: #909399;
          margin: 0;
        }
      }
      
      .report-summary {
        margin-bottom: 24px;
        
        .summary-item {
          text-align: center;
          padding: 16px;
          background: #f8f9fa;
          border-radius: 8px;
          
          .summary-number {
            font-size: 24px;
            font-weight: bold;
            color: var(--primary-color);
            margin-bottom: 4px;
          }
          
          .summary-label {
            font-size: 12px;
            color: #606266;
          }
        }
      }
      
      .report-charts {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 20px;
        margin-bottom: 24px;
        
        .chart-placeholder {
          height: 200px;
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
          background: #f8f9fa;
          border-radius: 8px;
          color: #909399;
          
          .chart-icon {
            font-size: 48px;
            margin-bottom: 16px;
            color: #c0c4cc;
          }
          
          p {
            margin: 0;
            font-size: 14px;
          }
        }
      }
      
      .report-details {
        h4 {
          margin: 0 0 16px 0;
          color: #303133;
        }
      }
      .go-next-wrapper {
        margin-top: 32px;
        text-align: center;
        display: flex;
        gap: 24px;
        justify-content: center;
      }
    }
    
    .empty-preview {
      height: 400px;
      display: flex;
      align-items: center;
      justify-content: center;
    }
  }
}

.history-card {
  .el-table {
    .el-button {
      margin-right: 8px;
    }
  }
}

// 响应式设计
@media (max-width: 768px) {
  .el-col {
    width: 100% !important;
    margin-bottom: 20px;
  }
  
  .report-charts {
    grid-template-columns: 1fr !important;
  }
}
</style> 