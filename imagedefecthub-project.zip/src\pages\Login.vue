<template>
  <div class="login-container">
    <div class="login-background">
      <div class="login-box">
        <div class="login-header">
          <div class="logo">
            <svg width="48" height="48" viewBox="0 0 48 48">
              <rect width="48" height="48" rx="12" fill="#7DC8FF"/>
              <text x="12" y="32" font-size="20" fill="#fff" font-family="Arial" font-weight="bold">IDH</text>
            </svg>
          </div>
          <h1>ImageDefectHub</h1>
          <p>智能图像缺陷识别与审核系统</p>
        </div>

        <el-form
          ref="loginFormRef"
          :model="loginForm"
          :rules="loginRules"
          class="login-form"
          @keyup.enter="handleLogin"
        >
          <el-form-item prop="username">
            <el-input
              v-model="loginForm.username"
              placeholder="请输入用户名"
              size="large"
              prefix-icon="User"
            />
          </el-form-item>

          <el-form-item prop="password">
            <el-input
              v-model="loginForm.password"
              type="password"
              placeholder="请输入密码"
              size="large"
              prefix-icon="Lock"
              show-password
            />
          </el-form-item>

          <el-form-item prop="captcha" v-if="showCaptcha">
            <div class="captcha-container">
              <el-input
                v-model="loginForm.captcha"
                placeholder="请输入验证码"
                size="large"
                style="flex: 1; margin-right: 12px;"
              />
              <div class="captcha-image" @click="refreshCaptcha">
                <canvas ref="captchaCanvas" width="120" height="40"></canvas>
              </div>
            </div>
          </el-form-item>

          <el-form-item>
            <div class="login-options">
              <el-checkbox v-model="loginForm.remember">记住密码</el-checkbox>
            </div>
          </el-form-item>

          <el-form-item>
            <el-button
              type="primary"
              size="large"
              class="login-button"
              :loading="loading"
              @click="handleLogin"
            >
              {{ loading ? '登录中...' : '登录' }}
            </el-button>
          </el-form-item>
        </el-form>

        <div class="login-footer">
          <p>还没有账号？<el-link type="primary">联系管理员</el-link></p>
          <p class="copyright">© 2024 ImageDefectHub. All rights reserved.</p>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { ElMessage } from 'element-plus'
import { User, Lock } from '@element-plus/icons-vue'

const router = useRouter()
const loginFormRef = ref()
const captchaCanvas = ref()
const loading = ref(false)
const showCaptcha = ref(true)

// 登录表单
const loginForm = reactive({
  username: '',
  password: '',
  captcha: '',
  remember: false
})

// 验证规则
const loginRules = {
  username: [
    { required: true, message: '请输入用户名', trigger: 'blur' },
    { min: 3, max: 20, message: '用户名长度在 3 到 20 个字符', trigger: 'blur' }
  ],
  password: [
    { required: true, message: '请输入密码', trigger: 'blur' },
    { min: 6, message: '密码长度不能少于 6 位', trigger: 'blur' }
  ],
  captcha: [
    { required: true, message: '请输入验证码', trigger: 'blur' },
    { len: 4, message: '验证码长度为 4 位', trigger: 'blur' }
  ]
}

// 生成验证码
const generateCaptcha = () => {
  const canvas = captchaCanvas.value
  if (!canvas) return

  const ctx = canvas.getContext('2d')
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'
  let captchaText = ''

  // 清空画布
  ctx.fillStyle = '#f0f2f5'
  ctx.fillRect(0, 0, 120, 40)

  // 生成随机验证码
  for (let i = 0; i < 4; i++) {
    const char = chars[Math.floor(Math.random() * chars.length)]
    captchaText += char
    
    ctx.font = 'bold 20px Arial'
    ctx.fillStyle = `hsl(${Math.random() * 360}, 70%, 50%)`
    ctx.fillText(char, 15 + i * 25, 25)
  }

  // 添加干扰线
  for (let i = 0; i < 3; i++) {
    ctx.strokeStyle = `hsl(${Math.random() * 360}, 70%, 70%)`
    ctx.lineWidth = 1
    ctx.beginPath()
    ctx.moveTo(Math.random() * 120, Math.random() * 40)
    ctx.lineTo(Math.random() * 120, Math.random() * 40)
    ctx.stroke()
  }

  // 添加干扰点
  for (let i = 0; i < 20; i++) {
    ctx.fillStyle = `hsl(${Math.random() * 360}, 70%, 70%)`
    ctx.fillRect(Math.random() * 120, Math.random() * 40, 1, 1)
  }

  // 保存验证码文本（实际项目中应该发送到后端验证）
  window.captchaText = captchaText
}

// 刷新验证码
const refreshCaptcha = () => {
  generateCaptcha()
  loginForm.captcha = ''
}

// 登录处理
const handleLogin = async () => {
  try {
    await loginFormRef.value.validate()
    
    // 验证码验证
    if (showCaptcha.value && loginForm.captcha.toUpperCase() !== window.captchaText) {
      ElMessage.error('验证码错误')
      refreshCaptcha()
      return
    }

    loading.value = true

    // 模拟登录API调用
    await new Promise(resolve => setTimeout(resolve, 1500))

    // 模拟登录成功
    if (loginForm.username === 'admin' && loginForm.password === '123456') {
      ElMessage.success('登录成功')
      
      // 保存登录状态
      localStorage.setItem('isLoggedIn', 'true')
      localStorage.setItem('userInfo', JSON.stringify({
        username: loginForm.username,
        loginTime: new Date().toISOString()
      }))

      // 跳转到首页
      router.push('/')
    } else {
      ElMessage.error('用户名或密码错误')
      if (showCaptcha.value) {
        refreshCaptcha()
      }
    }
  } catch (error) {
    console.error('登录失败:', error)
  } finally {
    loading.value = false
  }
}

// 页面加载时生成验证码
onMounted(() => {
  generateCaptcha()
  
  // 检查是否已登录
  const isLoggedIn = localStorage.getItem('isLoggedIn')
  if (isLoggedIn === 'true') {
    router.push('/')
  }
})
</script>

<style lang="scss" scoped>
.login-container {
  height: 100vh;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  display: flex;
  align-items: center;
  justify-content: center;
}

.login-background {
  width: 100%;
  max-width: 400px;
  padding: 20px;
}

.login-box {
  background: white;
  border-radius: 16px;
  padding: 40px;
  box-shadow: 0 20px 40px rgba(0, 0, 0, 0.1);
}

.login-header {
  text-align: center;
  margin-bottom: 32px;

  .logo {
    margin-bottom: 16px;
  }

  h1 {
    font-size: 28px;
    font-weight: 600;
    color: #333;
    margin-bottom: 8px;
  }

  p {
    color: #666;
    font-size: 14px;
  }
}

.login-form {
  .el-form-item {
    margin-bottom: 20px;
  }

  .login-options {
    display: flex;
    justify-content: space-between;
    align-items: center;
  }

  .login-button {
    width: 100%;
    height: 48px;
    font-size: 16px;
    font-weight: 500;
  }
}

.captcha-container {
  display: flex;
  align-items: center;

  .captcha-image {
    cursor: pointer;
    border: 1px solid #dcdfe6;
    border-radius: 4px;
    overflow: hidden;
    
    &:hover {
      border-color: var(--primary-color);
    }
  }
}

.login-footer {
  text-align: center;
  margin-top: 24px;
  padding-top: 24px;
  border-top: 1px solid #f0f0f0;

  p {
    margin: 8px 0;
    color: #666;
    font-size: 14px;
  }

  .copyright {
    font-size: 12px;
    color: #999;
  }
}

// 响应式设计
@media (max-width: 480px) {
  .login-background {
    padding: 10px;
  }

  .login-box {
    padding: 24px;
  }

  .login-header h1 {
    font-size: 24px;
  }
}
</style> 