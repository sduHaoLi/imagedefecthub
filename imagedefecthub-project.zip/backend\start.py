#!/usr/bin/env python3
"""
ImageDefectHub 后端启动脚本
"""

import os
import sys
import uvicorn
from pathlib import Path

# 添加项目根目录到Python路径
project_root = Path(__file__).parent
sys.path.insert(0, str(project_root))

from models.database import create_tables
from config import settings

def create_directories():
    """创建必要的目录"""
    directories = [
        settings.UPLOAD_DIR,
        os.path.join(settings.UPLOAD_DIR, "avatars"),
        "reports",
        "models"
    ]
    
    for directory in directories:
        os.makedirs(directory, exist_ok=True)
        print(f"✅ 创建目录: {directory}")

def init_database():
    """初始化数据库"""
    try:
        create_tables()
        print("✅ 数据库表创建成功")
    except Exception as e:
        print(f"❌ 数据库初始化失败: {e}")
        print("请检查数据库连接配置")

def check_dependencies():
    """检查依赖"""
    try:
        import fastapi
        import uvicorn
        import sqlalchemy
        import ultralytics
        import opencv_python
        import pillow
        print("✅ 所有依赖包已安装")
    except ImportError as e:
        print(f"❌ 缺少依赖包: {e}")
        print("请运行: pip install -r requirements.txt")
        return False
    return True

def main():
    """主函数"""
    print("🚀 启动 ImageDefectHub 后端服务...")
    
    # 检查依赖
    if not check_dependencies():
        return
    
    # 创建目录
    create_directories()
    
    # 初始化数据库
    init_database()
    
    print(f"📡 服务将在 http://{settings.HOST}:{settings.PORT} 启动")
    print("📚 API文档地址: http://localhost:8000/docs")
    print("🔧 按 Ctrl+C 停止服务")
    
    # 启动服务
    uvicorn.run(
        "main:app",
        host=settings.HOST,
        port=settings.PORT,
        reload=settings.DEBUG,
        log_level="info"
    )

if __name__ == "__main__":
    main() 