import os
from dotenv import load_dotenv

load_dotenv()

class Settings:
    # 数据库配置
    DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./imagedefecthub.db")
    
    # JWT配置
    SECRET_KEY = os.getenv("SECRET_KEY", "your-secret-key-here")
    ALGORITHM = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES = 30
    
    # 文件上传配置
    UPLOAD_DIR = "uploads"
    MAX_FILE_SIZE = 10 * 1024 * 1024  # 10MB
    ALLOWED_EXTENSIONS = {".jpg", ".jpeg", ".png", ".bmp"}
    
    # YOLO模型配置
    MODEL_PATH = os.getenv("MODEL_PATH", "models/best.pt")
    CONFIDENCE_THRESHOLD = float(os.getenv("CONFIDENCE_THRESHOLD", "0.5"))
    NMS_THRESHOLD = float(os.getenv("NMS_THRESHOLD", "0.4"))
    
    # Redis配置（用于缓存和任务队列）
    REDIS_URL = os.getenv("REDIS_URL", "redis://localhost:6379/0")
    
    # 应用配置
    DEBUG = os.getenv("DEBUG", "False").lower() == "true"
    HOST = os.getenv("HOST", "0.0.0.0")
    PORT = int(os.getenv("PORT", "8000"))

settings = Settings() 