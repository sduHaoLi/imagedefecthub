import cv2
import numpy as np
from ultralytics import YOLO
import os
from typing import List, Dict, Any
from PIL import Image
import io
from config import settings

class YOLODetector:
    def __init__(self):
        self.model = None
        self.confidence_threshold = settings.CONFIDENCE_THRESHOLD
        self.nms_threshold = settings.NMS_THRESHOLD
        self.load_model()
    
    def load_model(self):
        """加载YOLO模型"""
        try:
            if os.path.exists(settings.MODEL_PATH):
                self.model = YOLO(settings.MODEL_PATH)
                print(f"✅ YOLO模型加载成功: {settings.MODEL_PATH}")
            else:
                # 如果没有训练好的模型，使用预训练模型
                self.model = YOLO('yolov8n.pt')
                print("⚠️ 使用预训练模型 yolov8n.pt")
        except Exception as e:
            print(f"❌ 模型加载失败: {e}")
            # 使用默认模型
            self.model = YOLO('yolov8n.pt')
    
    def preprocess_image(self, image_data: bytes) -> np.ndarray:
        """预处理图像"""
        try:
            # 将字节数据转换为PIL图像
            image = Image.open(io.BytesIO(image_data))
            
            # 转换为RGB格式
            if image.mode != 'RGB':
                image = image.convert('RGB')
            
            # 转换为numpy数组
            image_array = np.array(image)
            
            return image_array
        except Exception as e:
            print(f"图像预处理失败: {e}")
            raise
    
    def detect_defects(self, image_data: bytes) -> List[Dict[str, Any]]:
        """检测图像中的缺陷"""
        try:
            # 预处理图像
            image_array = self.preprocess_image(image_data)
            
            # 使用YOLO进行检测
            results = self.model(image_array, conf=self.confidence_threshold, iou=self.nms_threshold)
            
            defects = []
            
            for result in results:
                boxes = result.boxes
                if boxes is not None:
                    for box in boxes:
                        # 获取边界框坐标
                        x1, y1, x2, y2 = box.xyxy[0].cpu().numpy()
                        
                        # 获取置信度
                        confidence = float(box.conf[0].cpu().numpy())
                        
                        # 获取类别
                        class_id = int(box.cls[0].cpu().numpy())
                        class_name = self.model.names[class_id]
                        
                        # 转换为相对坐标
                        height, width = image_array.shape[:2]
                        x_center = (x1 + x2) / 2 / width
                        y_center = (y1 + y2) / 2 / height
                        w = (x2 - x1) / width
                        h = (y2 - y1) / height
                        
                        defect = {
                            "defect_type": class_name,
                            "confidence": confidence,
                            "bbox": [x_center, y_center, w, h],
                            "bbox_absolute": [int(x1), int(y1), int(x2), int(y2)],
                            "class_id": class_id
                        }
                        
                        defects.append(defect)
            
            return defects
            
        except Exception as e:
            print(f"缺陷检测失败: {e}")
            return []
    
    def get_defect_statistics(self, defects: List[Dict[str, Any]]) -> Dict[str, Any]:
        """获取缺陷统计信息"""
        if not defects:
            return {
                "total_defects": 0,
                "defect_types": {},
                "avg_confidence": 0.0
            }
        
        defect_types = {}
        total_confidence = 0.0
        
        for defect in defects:
            defect_type = defect["defect_type"]
            confidence = defect["confidence"]
            
            if defect_type not in defect_types:
                defect_types[defect_type] = 0
            defect_types[defect_type] += 1
            
            total_confidence += confidence
        
        return {
            "total_defects": len(defects),
            "defect_types": defect_types,
            "avg_confidence": total_confidence / len(defects) if defects else 0.0
        }

# 创建全局检测器实例
detector = YOLODetector() 