from fastapi import APIRouter, HTTPException, Depends, Query
from fastapi.responses import JSONResponse, FileResponse
from pydantic import BaseModel
from typing import List, Optional
import os
import json
from datetime import datetime
from sqlalchemy.orm import Session
import pandas as pd
from reportlab.lib.pagesizes import letter
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.lib import colors

from models.database import get_db, Report, Image, DetectionResult, AuditRecord, User
from utils.auth import get_current_user
from config import settings

router = APIRouter()

class ReportRequest(BaseModel):
    report_type: str  # single, batch, summary
    image_ids: Optional[List[int]] = None
    defect_types: Optional[List[str]] = None
    start_date: Optional[str] = None
    end_date: Optional[str] = None
    format: str = "pdf"  # pdf, excel, json

@router.post("/generate")
async def generate_report(
    report_data: ReportRequest,
    current_user: str = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """生成报告"""
    try:
        # 获取当前用户ID
        user = db.query(User).filter(User.username == current_user).first()
        if not user:
            raise HTTPException(status_code=404, detail="用户不存在")
        
        # 根据报告类型获取数据
        if report_data.report_type == "single":
            if not report_data.image_ids or len(report_data.image_ids) != 1:
                raise HTTPException(status_code=400, detail="单张图片报告需要指定一张图片")
            
            image_id = report_data.image_ids[0]
            image = db.query(Image).filter(Image.id == image_id).first()
            if not image:
                raise HTTPException(status_code=404, detail="图片不存在")
            
            # 获取检测结果
            detection_results = db.query(DetectionResult).filter(
                DetectionResult.image_id == image_id
            ).all()
            
            report_data_dict = {
                "image_info": {
                    "id": image.id,
                    "name": image.original_name,
                    "size": image.file_size,
                    "uploaded_at": image.uploaded_at.isoformat()
                },
                "detection_results": [
                    {
                        "defect_type": result.defect_type,
                        "confidence": result.confidence,
                        "bbox": [result.bbox_x, result.bbox_y, result.bbox_width, result.bbox_height]
                    }
                    for result in detection_results
                ]
            }
            
        elif report_data.report_type == "batch":
            if not report_data.image_ids:
                raise HTTPException(status_code=400, detail="批量报告需要指定图片ID列表")
            
            images = db.query(Image).filter(Image.id.in_(report_data.image_ids)).all()
            
            report_data_dict = {
                "images": [
                    {
                        "id": image.id,
                        "name": image.original_name,
                        "size": image.file_size,
                        "uploaded_at": image.uploaded_at.isoformat()
                    }
                    for image in images
                ],
                "total_images": len(images)
            }
            
        elif report_data.report_type == "summary":
            # 构建查询条件
            query = db.query(DetectionResult).join(Image)
            
            if report_data.start_date:
                query = query.filter(Image.uploaded_at >= report_data.start_date)
            if report_data.end_date:
                query = query.filter(Image.uploaded_at <= report_data.end_date)
            if report_data.defect_types:
                query = query.filter(DetectionResult.defect_type.in_(report_data.defect_types))
            
            detection_results = query.all()
            
            # 统计信息
            defect_stats = {}
            for result in detection_results:
                defect_type = result.defect_type
                if defect_type not in defect_stats:
                    defect_stats[defect_type] = {"count": 0, "avg_confidence": 0}
                defect_stats[defect_type]["count"] += 1
                defect_stats[defect_type]["avg_confidence"] += result.confidence
            
            for defect_type in defect_stats:
                defect_stats[defect_type]["avg_confidence"] /= defect_stats[defect_type]["count"]
            
            report_data_dict = {
                "summary": {
                    "total_defects": len(detection_results),
                    "defect_types": len(defect_stats),
                    "defect_statistics": defect_stats
                },
                "date_range": {
                    "start_date": report_data.start_date,
                    "end_date": report_data.end_date
                }
            }
        
        else:
            raise HTTPException(status_code=400, detail="不支持的报告类型")
        
        # 生成报告文件
        report_filename = f"report_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        
        if report_data.format == "pdf":
            file_path = await generate_pdf_report(report_filename, report_data_dict, report_data.report_type)
        elif report_data.format == "excel":
            file_path = await generate_excel_report(report_filename, report_data_dict, report_data.report_type)
        elif report_data.format == "json":
            file_path = await generate_json_report(report_filename, report_data_dict, report_data.report_type)
        else:
            raise HTTPException(status_code=400, detail="不支持的报告格式")
        
        # 保存报告记录到数据库
        report_record = Report(
            report_name=f"{report_data.report_type}_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}",
            report_type=report_data.report_type,
            file_path=file_path,
            file_size=os.path.getsize(file_path) if os.path.exists(file_path) else 0,
            generated_by=user.id,
            parameters=json.dumps(report_data.dict())
        )
        
        db.add(report_record)
        db.commit()
        
        return JSONResponse(content={
            "code": 200,
            "message": "报告生成成功",
            "data": {
                "report_id": report_record.id,
                "report_name": report_record.report_name,
                "file_path": file_path,
                "file_size": report_record.file_size,
                "generated_at": report_record.generated_at.isoformat()
            }
        })
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"生成报告失败: {str(e)}")

async def generate_pdf_report(filename: str, data: dict, report_type: str) -> str:
    """生成PDF报告"""
    file_path = f"reports/{filename}.pdf"
    os.makedirs("reports", exist_ok=True)
    
    doc = SimpleDocTemplate(file_path, pagesize=letter)
    styles = getSampleStyleSheet()
    story = []
    
    # 标题
    title = Paragraph(f"ImageDefectHub {report_type.title()} Report", styles['Title'])
    story.append(title)
    story.append(Spacer(1, 12))
    
    # 生成时间
    story.append(Paragraph(f"Generated at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}", styles['Normal']))
    story.append(Spacer(1, 12))
    
    if report_type == "single":
        # 单张图片报告
        image_info = data["image_info"]
        story.append(Paragraph(f"Image: {image_info['name']}", styles['Heading2']))
        story.append(Paragraph(f"Size: {image_info['size']} bytes", styles['Normal']))
        story.append(Paragraph(f"Uploaded: {image_info['uploaded_at']}", styles['Normal']))
        story.append(Spacer(1, 12))
        
        # 缺陷检测结果
        defects = data["detection_results"]
        if defects:
            story.append(Paragraph("Defect Detection Results:", styles['Heading2']))
            defect_data = [["Defect Type", "Confidence", "BBox"]]
            for defect in defects:
                defect_data.append([
                    defect["defect_type"],
                    f"{defect['confidence']:.2f}",
                    f"[{defect['bbox'][0]:.2f}, {defect['bbox'][1]:.2f}, {defect['bbox'][2]:.2f}, {defect['bbox'][3]:.2f}]"
                ])
            table = Table(defect_data)
            table.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
                ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
                ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
                ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                ('FONTSIZE', (0, 0), (-1, 0), 14),
                ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
                ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
                ('GRID', (0, 0), (-1, -1), 1, colors.black)
            ]))
            story.append(table)
        else:
            story.append(Paragraph("No defects detected.", styles['Normal']))
    
    doc.build(story)
    return file_path

async def generate_excel_report(filename: str, data: dict, report_type: str) -> str:
    """生成Excel报告"""
    file_path = f"reports/{filename}.xlsx"
    os.makedirs("reports", exist_ok=True)
    
    if report_type == "single":
        # 单张图片报告
        image_info = data["image_info"]
        defects = data["detection_results"]
        
        # 创建DataFrame
        if defects:
            df = pd.DataFrame(defects)
            df['image_name'] = image_info['name']
            df['image_size'] = image_info['size']
            df['uploaded_at'] = image_info['uploaded_at']
        else:
            df = pd.DataFrame({
                'image_name': [image_info['name']],
                'image_size': [image_info['size']],
                'uploaded_at': [image_info['uploaded_at']],
                'defect_type': ['No defects detected'],
                'confidence': [0],
                'bbox': ['[]']
            })
    
    elif report_type == "batch":
        # 批量报告
        images = data["images"]
        df = pd.DataFrame(images)
    
    elif report_type == "summary":
        # 汇总报告
        summary = data["summary"]
        defect_stats = summary["defect_statistics"]
        
        df = pd.DataFrame([
            {
                'defect_type': defect_type,
                'count': stats['count'],
                'avg_confidence': stats['avg_confidence']
            }
            for defect_type, stats in defect_stats.items()
        ])
    
    df.to_excel(file_path, index=False)
    return file_path

async def generate_json_report(filename: str, data: dict, report_type: str) -> str:
    """生成JSON报告"""
    file_path = f"reports/{filename}.json"
    os.makedirs("reports", exist_ok=True)
    
    report_data = {
        "report_type": report_type,
        "generated_at": datetime.now().isoformat(),
        "data": data
    }
    
    with open(file_path, 'w', encoding='utf-8') as f:
        json.dump(report_data, f, ensure_ascii=False, indent=2)
    
    return file_path

@router.get("/download/{report_id}")
async def download_report(
    report_id: int,
    db: Session = Depends(get_db)
):
    """下载报告"""
    try:
        report = db.query(Report).filter(Report.id == report_id).first()
        
        if not report:
            raise HTTPException(status_code=404, detail="报告不存在")
        
        if not os.path.exists(report.file_path):
            raise HTTPException(status_code=404, detail="报告文件不存在")
        
        return FileResponse(
            path=report.file_path,
            filename=os.path.basename(report.file_path),
            media_type='application/octet-stream'
        )
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"下载报告失败: {str(e)}")

@router.get("/history")
async def get_report_history(
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    db: Session = Depends(get_db)
):
    """获取报告历史"""
    try:
        query = db.query(Report).order_by(Report.generated_at.desc())
        
        total = query.count()
        reports = query.offset((page - 1) * page_size).limit(page_size).all()
        
        report_list = []
        for report in reports:
            report_list.append({
                "id": report.id,
                "report_name": report.report_name,
                "report_type": report.report_type,
                "file_size": report.file_size,
                "generated_at": report.generated_at.isoformat(),
                "parameters": json.loads(report.parameters) if report.parameters else {}
            })
        
        return JSONResponse(content={
            "code": 200,
            "data": {
                "reports": report_list,
                "pagination": {
                    "page": page,
                    "page_size": page_size,
                    "total": total,
                    "total_pages": (total + page_size - 1) // page_size
                }
            }
        })
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"获取报告历史失败: {str(e)}") 