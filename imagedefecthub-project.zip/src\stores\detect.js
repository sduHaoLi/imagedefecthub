import { defineStore } from 'pinia'

export const useDetectStore = defineStore('detect', {
  state: () => ({
    detectionResults: [],
    selectedImages: []
  }),
  actions: {
    setDetectionResults(results) {
      this.detectionResults = results
    },
    clearDetectionResults() {
      this.detectionResults = []
    },
    setSelectedImages(images) {
      this.selectedImages = images
    },
    clearSelectedImages() {
      this.selectedImages = []
    }
  }
}) 