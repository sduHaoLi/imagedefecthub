import { createRouter, createWebHistory } from 'vue-router'

const routes = [
  {
    path: '/login',
    name: 'Login',
    component: () => import('@/pages/Login.vue'),
    meta: { title: '登录' }
  },
  {
    path: '/',
    name: 'Dashboard',
    component: () => import('@/pages/Dashboard.vue'),
    meta: { title: '数据统计', requiresAuth: true }
  },
  {
    path: '/images',
    name: 'ImageManage',
    component: () => import('@/pages/ImageManage.vue'),
    meta: { title: '图像管理', requiresAuth: true }
  },
  {
    path: '/detect',
    name: 'DefectDetect',
    component: () => import('@/pages/DefectDetect.vue'),
    meta: { title: '缺陷识别', requiresAuth: true }
  },
  {
    path: '/audit',
    name: 'DefectAudit',
    component: () => import('@/pages/DefectAudit.vue'),
    meta: { title: '缺陷审核', requiresAuth: true }
  },
  {
    path: '/report',
    name: 'ReportCenter',
    component: () => import('@/pages/ReportCenter.vue'),
    meta: { title: '报告中心', requiresAuth: true }
  },
  {
    path: '/profile',
    name: 'Profile',
    component: () => import('@/pages/Profile.vue'),
    meta: { title: '个人信息', requiresAuth: true }
  }
]

const router = createRouter({
  history: createWebHistory(),
  routes
})

// 路由守卫
router.beforeEach((to, from, next) => {
  document.title = `${to.meta.title} - ImageDefectHub`
  
  // 检查是否需要登录认证
  if (to.meta.requiresAuth) {
    const isLoggedIn = localStorage.getItem('isLoggedIn')
    if (isLoggedIn !== 'true') {
      // 未登录，跳转到登录页
      next('/login')
      return
    }
  }
  
  // 如果已登录且访问登录页，跳转到首页
  if (to.path === '/login') {
    const isLoggedIn = localStorage.getItem('isLoggedIn')
    if (isLoggedIn === 'true') {
      next('/')
      return
    }
  }
  
  next()
})

export default router 