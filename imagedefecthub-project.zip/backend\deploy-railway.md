# Railway 部署指南

## 1. 注册 Railway 账号
访问 https://railway.app/ 注册账号

## 2. 创建新项目
1. 点击 "New Project"
2. 选择 "Deploy from GitHub repo"
3. 选择你的 GitHub 仓库

## 3. 配置环境变量
在 Railway 控制台 → Variables 中添加：

```
DATABASE_URL=sqlite:///./imagedefecthub.db
SECRET_KEY=your-very-secure-secret-key-here
DEBUG=False
MODEL_PATH=models/best.pt
CONFIDENCE_THRESHOLD=0.5
NMS_THRESHOLD=0.4
```

## 4. 部署设置
- Build Command: `pip install -r requirements.txt`
- Start Command: `uvicorn main:app --host 0.0.0.0 --port $PORT`

## 5. 获取部署 URL
部署完成后，Railway 会提供一个 URL，类似：
`https://your-app-name.railway.app`

## 6. 更新前端配置
在 Netlify 环境变量中添加：
```
VITE_API_BASE_URL=https://your-app-name.railway.app/api
``` 