# Railway 部署详细指南

## 准备工作

### 1. 确保代码结构正确
```
backend/
├── main.py              # FastAPI 主应用
├── config.py            # 配置文件
├── requirements.txt     # Python 依赖
├── Procfile            # Railway 启动命令
├── runtime.txt         # Python 版本
├── railway.json        # Railway 配置
└── api/                # API 路由
    ├── auth.py
    ├── images.py
    ├── detect.py
    ├── audit.py
    ├── reports.py
    └── users.py
```

### 2. 检查关键文件

#### main.py
- 确保 CORS 配置正确
- 确保路由注册完整
- 确保健康检查端点存在

#### config.py
- 使用 SQLite 作为默认数据库
- 生产环境配置
- 环境变量读取

#### requirements.txt
- 使用稳定版本
- 移除可能有问题的包
- 添加必要的依赖

## 部署步骤

### 1. 注册 Railway 账号
访问 https://railway.app/ 使用 GitHub 账号注册

### 2. 创建新项目
1. 点击 "New Project"
2. 选择 "Deploy from GitHub repo"
3. 选择你的 GitHub 仓库
4. 选择 `backend` 目录作为根目录

### 3. 配置环境变量
在 Railway 控制台 → Variables 中添加：

```
DATABASE_URL=sqlite:///./imagedefecthub.db
SECRET_KEY=your-very-secure-secret-key-here-change-this
DEBUG=false
MODEL_PATH=models/best.pt
CONFIDENCE_THRESHOLD=0.5
NMS_THRESHOLD=0.4
```

### 4. 部署设置
- Build Command: `pip install -r requirements.txt`
- Start Command: `uvicorn main:app --host 0.0.0.0 --port $PORT`

### 5. 等待部署
Railway 会自动：
1. 克隆代码
2. 安装依赖
3. 启动服务
4. 分配域名

### 6. 获取部署 URL
部署完成后，你会得到一个 URL，类似：
`https://your-app-name.railway.app`

### 7. 测试 API
访问 `https://your-app-name.railway.app/docs` 查看 API 文档

## 故障排除

### 构建失败
- 检查 `requirements.txt` 中的包版本
- 确认 Python 版本兼容
- 查看构建日志

### 启动失败
- 检查 `main.py` 中的导入
- 确认环境变量设置
- 查看启动日志

### API 无法访问
- 检查 CORS 配置
- 确认端口设置
- 验证域名配置

## 更新部署

### 自动部署
每次推送到 GitHub 主分支，Railway 会自动重新部署

### 手动部署
在 Railway 控制台点击 "Deploy" 按钮

## 监控和维护

### 查看日志
在 Railway 控制台 → Deployments → 选择部署 → Logs

### 查看指标
在 Railway 控制台 → Metrics 查看性能指标

### 环境变量管理
在 Railway 控制台 → Variables 管理环境变量 